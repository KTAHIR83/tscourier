export type ConsignmentStatus =
  | 'Booked'
  | 'In Transit'
  | 'Arrived at Hub'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Pending'
  | 'Cancelled';

export type ServiceType =
  | 'Air Express'
  | 'Surface Cargo'
  | 'Priority Express'
  | 'Same Day';

export type PaymentType = 'Prepaid' | 'To Pay' | 'COD' | 'Credit';

export interface TrackingEvent {
  step: string;
  status: string;
  timestamp: string;
  location: string;
  note: string;
  completed: boolean;
}

export interface Consignment {
  id: string;
  awbNo: string;
  customer: string;
  customerId?: string;
  referenceNo?: string;
  fromCity: string;
  toCity: string;
  destination: string;
  bookingDate: string;
  estimatedDeliveryDate?: string;
  deliveryDate?: string;
  serviceType: ServiceType;
  paymentType: PaymentType;
  weightKg: number;
  pieces: number;
  declaredValue: number;
  baseFreight: number;
  fuelSurcharge: number;
  taxAmount: number;
  totalAmount: number;
  consigneeName: string;
  consigneePhone: string;
  consigneeAddress: string;
  consigneeArea: string;
  consigneePincode: string;
  status: ConsignmentStatus;
  notes?: string;
  timeline: TrackingEvent[];
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  gstin: string;
  city: string;
  state: string;
  pincode: string;
  status: 'Active' | 'Inactive';
  creditLimit: number;
  balance: number;
  createdDate: string;
}

export interface City {
  id: string;
  code: string;
  name: string;
  state: string;
  country: string;
  pincode: string;
  zone: 'North' | 'South' | 'East' | 'West' | 'Central';
  status: 'Active' | 'Inactive';
  createdDate: string;
}

export interface Area {
  id: string;
  name: string;
  cityId: string;
  cityName: string;
  pincode: string;
  deliveryZone: string;
  status: 'Active' | 'Inactive';
}

export interface Slab {
  id: string;
  slabCode: string;
  slabName: string;
  minWeightKg: number;
  maxWeightKg: number;
  ratePerKg: number;
  expressRate: number;
  status: 'Active' | 'Inactive';
}

export interface Route {
  id: string;
  routeCode: string;
  routeName: string;
  originCity: string;
  destinationCity: string;
  transitTimeHours: number;
  distanceKm: number;
  status: 'Active' | 'Inactive';
}

export interface Employee {
  id: string;
  empCode: string;
  name: string;
  role: 'Station Manager' | 'Operations Executive' | 'Driver' | 'Hub Dispatcher' | 'Accountant';
  phone: string;
  email: string;
  branchCity: string;
  status: 'Active' | 'Inactive';
}

export interface ManifestCompany {
  id: string;
  code: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  hubCity: string;
  status: 'Active' | 'Inactive';
}

export interface Station {
  id: string;
  stationCode: string;
  stationName: string;
  city: string;
  inCharge: string;
  contactNumber: string;
  capacity: string;
  status: 'Active' | 'Inactive';
}

export interface Loader {
  id: string;
  loaderCode: string;
  name: string;
  contactPerson: string;
  phone: string;
  vehicleCount: number;
  status: 'Active' | 'Inactive';
}

export interface TaxMaster {
  id: string;
  taxCode: string;
  taxName: string;
  cgstRate: number;
  sgstRate: number;
  igstRate: number;
  totalRate: number;
  effectiveFrom: string;
  status: 'Active' | 'Inactive';
}

export interface SupplierCourier {
  id: string;
  code: string;
  name: string;
  serviceTypes: string;
  contactNumber: string;
  trackingUrl: string;
  status: 'Active' | 'Inactive';
}

export interface Manifest {
  id: string;
  manifestNo: string;
  date: string;
  manifestCompany: string;
  coLoader: string;
  route: string;
  vehicleNo: string;
  driverName: string;
  driverPhone: string;
  consignmentsCount: number;
  totalWeightKg: number;
  status: 'Created' | 'Dispatched' | 'In Transit' | 'Received at Hub';
  attachedAwbs: string[];
}

export interface SystemAlert {
  id: string;
  title: string;
  message: string;
  severity: 'warning' | 'info' | 'success' | 'danger';
  timestamp: string;
  unread: boolean;
  link?: string;
}
