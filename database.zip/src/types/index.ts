export type ShipmentStatus = 
  | 'Booked'
  | 'Picked Up'
  | 'In Transit'
  | 'Arrived at Hub'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Pending'
  | 'Cancelled';

export type ServiceType = 'Express Air' | 'Surface Cargo' | 'Standard Express' | 'Same Day Hub';
export type PaymentType = 'Paid' | 'To-Pay' | 'TBB (To-Be-Billed)' | 'COD';

export interface Consignment {
  id: string;
  awbNumber: string;
  customerId: string;
  customerName: string;
  senderPhone?: string;
  recipientName: string;
  recipientPhone: string;
  fromCity: string;
  toCity: string;
  serviceType: ServiceType;
  paymentType: PaymentType;
  weight: number; // in kg
  pieces: number;
  declaredValue: number; // in INR
  deliveryAddress: string;
  area: string;
  pinCode: string;
  status: ShipmentStatus;
  bookingDate: string;
  deliveredDate?: string;
  currentLocation?: string;
  notes?: string;
  specialInstructions?: string;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  city: string;
  gstNo: string;
  outstandingBalance: number;
  creditLimit: number;
  status: 'Active' | 'Inactive';
  createdDate: string;
}

export interface CityMaster {
  id: string;
  cityName: string;
  state: string;
  country: string;
  pinCode: string;
  zone: 'North' | 'South' | 'East' | 'West' | 'Central' | 'North-East';
  status: 'Active' | 'Inactive';
  createdDate: string;
}

export interface AreaMaster {
  id: string;
  areaName: string;
  cityName: string;
  state: string;
  pinCode: string;
  deliveryHub: string;
  status: 'Active' | 'Inactive';
}

export interface SlabMaster {
  id: string;
  slabCode: string;
  slabName: string;
  serviceType: ServiceType;
  minWeightKg: number;
  maxWeightKg: number;
  baseRate: number;
  extraRatePerKg: number;
  status: 'Active' | 'Inactive';
}

export interface RouteMaster {
  id: string;
  routeCode: string;
  originCity: string;
  destinationCity: string;
  viaCities: string[];
  distanceKm: number;
  standardTransitDays: number;
  status: 'Active' | 'Inactive';
}

export interface EmployeeMaster {
  id: string;
  empCode: string;
  name: string;
  designation: string;
  department: 'Operations' | 'Logistics' | 'Accounts' | 'Dispatch' | 'Management';
  branch: string;
  phone: string;
  email: string;
  status: 'Active' | 'Inactive';
}

export interface ManifestCompanyMaster {
  id: string;
  companyCode: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  email: string;
  city: string;
  gstNo: string;
  status: 'Active' | 'Inactive';
}

export interface StationMaster {
  id: string;
  stationCode: string;
  stationName: string;
  city: string;
  state: string;
  hubType: 'Mother Hub' | 'Delivery Hub' | 'Transit Station' | 'Airport Gateway';
  contactPerson: string;
  phone: string;
  status: 'Active' | 'Inactive';
}

export interface ManifestCoLoaderMaster {
  id: string;
  loaderCode: string;
  loaderName: string;
  supportedServices: string[];
  contactPerson: string;
  phone: string;
  city: string;
  status: 'Active' | 'Inactive';
}

export interface TaxMaster {
  id: string;
  taxCode: string;
  taxName: string;
  hsnCode: string;
  cgstRate: number;
  sgstRate: number;
  igstRate: number;
  effectiveFrom: string;
  status: 'Active' | 'Inactive';
}

export interface SupplierCourierMaster {
  id: string;
  supplierCode: string;
  courierName: string;
  serviceModes: string[];
  trackingPortalUrl: string;
  contactPerson: string;
  phone: string;
  status: 'Active' | 'Inactive';
}

export interface Manifest {
  id: string;
  manifestNo: string;
  date: string;
  carrierName: string;
  coLoader: string;
  routeCode: string;
  originCity: string;
  destCity: string;
  consignmentCount: number;
  totalWeight: number;
  totalPieces: number;
  vehicleNo?: string;
  driverName?: string;
  driverPhone?: string;
  status: 'Draft' | 'Dispatched' | 'In Transit' | 'Received at Hub' | 'Closed';
}

export interface TrackingEvent {
  timestamp: string;
  location: string;
  status: ShipmentStatus;
  description: string;
  facility?: string;
}

export interface SystemAlert {
  id: string;
  title: string;
  message: string;
  type: 'warning' | 'info' | 'success' | 'alert';
  timestamp: string;
  read: boolean;
  link?: string;
}

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  email: string;
  role: 'Administrator' | 'Operations Manager' | 'Dispatch Officer' | 'Accountant';
  branch: string;
  avatarUrl?: string;
}

export type ActiveNav = 
  | 'dashboard'
  | 'master-overview'
  | 'master-customers'
  | 'master-cities'
  | 'master-areas'
  | 'master-slabs'
  | 'master-routes'
  | 'master-employees'
  | 'master-manifest-companies'
  | 'master-stations'
  | 'master-loaders'
  | 'master-tax'
  | 'master-suppliers'
  | 'transactions-consignments'
  | 'transactions-create-consignment'
  | 'transactions-manifests'
  | 'transactions-tracking'
  | 'reports'
  | 'database-utility'
  | 'settings';
