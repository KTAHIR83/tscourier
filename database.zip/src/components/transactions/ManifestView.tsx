'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Manifest } from '@/types';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Modal } from '@/components/ui/Modal';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Download,
  Truck,
  Printer,
  Boxes,
} from 'lucide-react';

export const ManifestView: React.FC = () => {
  const { manifests, addManifest, routes, manifestCompanies, loaders, cities } = useApp();

  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [printManifest, setPrintManifest] = useState<Manifest | null>(null);

  // Form states
  const [carrierName, setCarrierName] = useState(manifestCompanies[0]?.companyName || 'Index Express Line');
  const [coLoader, setCoLoader] = useState(loaders[0]?.loaderName || 'IndiGo Cargo Logistics');
  const [routeCode, setRouteCode] = useState(routes[0]?.routeCode || 'RT-DEL-BOM');
  const [originCity, setOriginCity] = useState('Delhi');
  const [destCity, setDestCity] = useState('Mumbai');
  const [consignmentCount, setConsignmentCount] = useState<number>(45);
  const [totalWeight, setTotalWeight] = useState<number>(320.5);
  const [totalPieces, setTotalPieces] = useState<number>(85);
  const [vehicleNo, setVehicleNo] = useState('DL-01-AB-8842');
  const [driverName, setDriverName] = useState('Suraj Bhan');
  const [driverPhone, setDriverPhone] = useState('+91 98112 34990');

  const filteredManifests = manifests.filter((m) => {
    const matchesSearch =
      m.manifestNo.toLowerCase().includes(search.toLowerCase()) ||
      m.carrierName.toLowerCase().includes(search.toLowerCase()) ||
      m.originCity.toLowerCase().includes(search.toLowerCase()) ||
      m.destCity.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filterStatus === 'All' || m.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const manifestNo = `MNF-2025-08-${100 + manifests.length + 1}`;
    addManifest({
      manifestNo,
      date: new Date().toISOString().split('T')[0],
      carrierName,
      coLoader,
      routeCode,
      originCity,
      destCity,
      consignmentCount: Number(consignmentCount),
      totalWeight: Number(totalWeight),
      totalPieces: Number(totalPieces),
      vehicleNo,
      driverName,
      driverPhone,
      status: 'Dispatched',
    });
    setIsModalOpen(false);
  };

  const exportCSV = () => {
    const headers = ['Manifest No,Date,Carrier,Co Loader,Route,Origin,Destination,Consignments,Weight (kg),Status'];
    const rows = filteredManifests.map(
      (m) => `"${m.manifestNo}","${m.date}","${m.carrierName}","${m.coLoader}","${m.routeCode}","${m.originCity}","${m.destCity}",${m.consignmentCount},${m.totalWeight},"${m.status}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TSIBIS_Manifests_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Manifest Operations
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Dispatch consolidation, line-haul run sheets, and airport/road freight handovers
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl text-white bg-blue-600 hover:bg-blue-700 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Manifest</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search manifest no, carrier, origin, destination..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40"
          />
        </div>

        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Dispatched">Dispatched</option>
              <option value="In Transit">In Transit</option>
              <option value="Received at Hub">Received at Hub</option>
              <option value="Closed">Closed</option>
            </select>
          </div>
          <span className="text-xs text-slate-400">
            {filteredManifests.length} manifests
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/70 dark:border-slate-800">
                <th className="py-3 px-4">Manifest No.</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Carrier & Co-Loader</th>
                <th className="py-3 px-4">Route Corridor</th>
                <th className="py-3 px-4">Shipments / Weight</th>
                <th className="py-3 px-4">Vehicle / Driver</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredManifests.length > 0 ? (
                filteredManifests.map((m) => (
                  <tr
                    key={m.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">
                      {m.manifestNo}
                    </td>
                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                      {m.date}
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900 dark:text-white">{m.carrierName}</p>
                      <p className="text-[11px] text-slate-400">{m.coLoader}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                      <span className="font-semibold">{m.originCity}</span>
                      <span className="text-slate-400 mx-1">→</span>
                      <span className="font-semibold text-blue-600 dark:text-cyan-400">{m.destCity}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">{m.routeCode}</span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                      <span>{m.consignmentCount} AWBs</span>
                      <span className="text-slate-400 block text-[11px]">{m.totalWeight} kg</span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      <p className="font-mono text-[11px]">{m.vehicleNo || 'Aviation Hub'}</p>
                      <p className="text-slate-400 text-[10px]">{m.driverName}</p>
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={m.status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => setPrintManifest(m)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg transition-colors"
                        title="Print Manifest"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Boxes className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-600 dark:text-slate-400">No manifests found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE MANIFEST MODAL */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create Line-Haul Manifest"
        subtitle="Consolidate booked shipments into vehicle / flight manifest"
        maxWidth="xl"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Carrier Company *
              </label>
              <select
                value={carrierName}
                onChange={(e) => setCarrierName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {manifestCompanies.map((mc) => (
                  <option key={mc.id} value={mc.companyName}>{mc.companyName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Co-Loader Partner
              </label>
              <select
                value={coLoader}
                onChange={(e) => setCoLoader(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {loaders.map((ld) => (
                  <option key={ld.id} value={ld.loaderName}>{ld.loaderName}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Origin City
              </label>
              <select
                value={originCity}
                onChange={(e) => setOriginCity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {cities.map((ct) => (
                  <option key={ct.id} value={ct.cityName}>{ct.cityName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Destination City
              </label>
              <select
                value={destCity}
                onChange={(e) => setDestCity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {cities.map((ct) => (
                  <option key={ct.id} value={ct.cityName}>{ct.cityName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Route Code
              </label>
              <select
                value={routeCode}
                onChange={(e) => setRouteCode(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono"
              >
                {routes.map((rt) => (
                  <option key={rt.id} value={rt.routeCode}>{rt.routeCode} ({rt.originCity}-{rt.destinationCity})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Consignments Count
              </label>
              <input
                type="number"
                min="1"
                required
                value={consignmentCount}
                onChange={(e) => setConsignmentCount(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Total Weight (kg)
              </label>
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={totalWeight}
                onChange={(e) => setTotalWeight(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Total Pieces
              </label>
              <input
                type="number"
                min="1"
                required
                value={totalPieces}
                onChange={(e) => setTotalPieces(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Vehicle No. / Flight
              </label>
              <input
                type="text"
                value={vehicleNo}
                onChange={(e) => setVehicleNo(e.target.value)}
                placeholder="e.g. DL-01-AB-8842"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Driver / Dispatcher Name
              </label>
              <input
                type="text"
                value={driverName}
                onChange={(e) => setDriverName(e.target.value)}
                placeholder="e.g. Ramesh Chandra"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Driver Contact Phone
              </label>
              <input
                type="text"
                value={driverPhone}
                onChange={(e) => setDriverPhone(e.target.value)}
                placeholder="+91 98000 00000"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors"
            >
              Dispatch Manifest
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT MANIFEST RUN SHEET MODAL */}
      <Modal
        isOpen={!!printManifest}
        onClose={() => setPrintManifest(null)}
        title="Line-Haul Dispatch Manifest"
        subtitle={`Manifest ID: ${printManifest?.manifestNo}`}
        maxWidth="2xl"
      >
        {printManifest && (
          <div className="p-4 bg-white dark:bg-slate-900 border rounded-xl space-y-4 text-xs">
            <div className="flex justify-between border-b pb-3">
              <div>
                <h4 className="font-black text-sm">TSIBIS SOLUTION - DISPATCH MANIFEST</h4>
                <p className="text-[10px] text-slate-500">Route: {printManifest.originCity} → {printManifest.destCity} ({printManifest.routeCode})</p>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-blue-600">{printManifest.manifestNo}</span>
                <p className="text-[10px] text-slate-400">{printManifest.date}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <div><span className="text-[10px] text-slate-400 block">Carrier</span><span className="font-bold">{printManifest.carrierName}</span></div>
              <div><span className="text-[10px] text-slate-400 block">Vehicle</span><span className="font-bold font-mono">{printManifest.vehicleNo}</span></div>
              <div><span className="text-[10px] text-slate-400 block">Driver</span><span className="font-bold">{printManifest.driverName}</span></div>
            </div>

            <div className="grid grid-cols-3 gap-3 p-3 border rounded-lg text-center">
              <div><span className="text-[10px] text-slate-400 block">Shipments Loaded</span><span className="font-black text-base">{printManifest.consignmentCount}</span></div>
              <div><span className="text-[10px] text-slate-400 block">Total Pieces</span><span className="font-black text-base">{printManifest.totalPieces}</span></div>
              <div><span className="text-[10px] text-slate-400 block">Gross Weight</span><span className="font-black text-base">{printManifest.totalWeight} kg</span></div>
            </div>

            <div className="pt-6 grid grid-cols-2 gap-8 text-[11px] text-slate-400">
              <div className="border-t pt-2 text-center">Origin Dispatch Supervisor Signature</div>
              <div className="border-t pt-2 text-center">Destination Receiving Officer Signature</div>
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Manifest</span>
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
