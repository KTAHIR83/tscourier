'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Consignment, ShipmentStatus } from '@/types';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Modal } from '@/components/ui/Modal';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  Download,
  Eye,
  Trash2,
  Printer,
  Compass,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';

export const ConsignmentListView: React.FC = () => {
  const {
    consignments,
    deleteConsignment,
    updateConsignmentStatus,
    setActiveNav,
    setQuickTrackAwb,
  } = useApp();

  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterService, setFilterService] = useState<string>('All');

  // Status update modal
  const [statusUpdateTarget, setStatusUpdateTarget] = useState<Consignment | null>(null);
  const [newStatus, setNewStatus] = useState<ShipmentStatus>('In Transit');
  const [newLocation, setNewLocation] = useState('');

  // Delete dialog
  const [deleteTarget, setDeleteTarget] = useState<Consignment | null>(null);

  // AWB Note print preview modal
  const [printPreviewCsg, setPrintPreviewCsg] = useState<Consignment | null>(null);

  const filteredConsignments = consignments.filter((c) => {
    const matchesSearch =
      c.awbNumber.toLowerCase().includes(search.toLowerCase()) ||
      c.customerName.toLowerCase().includes(search.toLowerCase()) ||
      c.fromCity.toLowerCase().includes(search.toLowerCase()) ||
      c.toCity.toLowerCase().includes(search.toLowerCase()) ||
      c.recipientName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filterStatus === 'All' || c.status === filterStatus;
    const matchesService = filterService === 'All' || c.serviceType === filterService;
    return matchesSearch && matchesStatus && matchesService;
  });

  const handleTrackClick = (awb: string) => {
    setQuickTrackAwb(awb);
    setActiveNav('transactions-tracking');
  };

  const handleOpenStatusModal = (csg: Consignment) => {
    setStatusUpdateTarget(csg);
    setNewStatus(csg.status);
    setNewLocation(csg.currentLocation || '');
  };

  const handleSaveStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (statusUpdateTarget) {
      updateConsignmentStatus(statusUpdateTarget.id, newStatus, newLocation);
      setStatusUpdateTarget(null);
    }
  };

  const exportCSV = () => {
    const headers = ['AWB Number,Customer,From City,To City,Service Type,Payment Type,Weight (kg),Pieces,Declared Value (INR),Status,Booking Date'];
    const rows = filteredConsignments.map(
      (c) => `"${c.awbNumber}","${c.customerName}","${c.fromCity}","${c.toCity}","${c.serviceType}","${c.paymentType}",${c.weight},${c.pieces},${c.declaredValue},"${c.status}","${c.bookingDate}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TSIBIS_Consignments_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-cyan-400 flex items-center justify-center">
              <Boxes className="w-4 h-4" />
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Consignments Register
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Browse, manage, and dispatch active freight consignments across India
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setActiveNav('transactions-create-consignment')}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl text-white bg-blue-600 hover:bg-blue-700 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>+ Create Consignment</span>
          </button>
        </div>
      </div>

      {/* FILTER & SEARCH */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search AWB, customer, city, recipient..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Booked">Booked</option>
              <option value="In Transit">In Transit</option>
              <option value="Arrived at Hub">Arrived at Hub</option>
              <option value="Out for Delivery">Out for Delivery</option>
              <option value="Delivered">Delivered</option>
              <option value="Pending">Pending</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span>Service:</span>
            <select
              value={filterService}
              onChange={(e) => setFilterService(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Services</option>
              <option value="Express Air">Express Air</option>
              <option value="Surface Cargo">Surface Cargo</option>
              <option value="Standard Express">Standard Express</option>
              <option value="Same Day Hub">Same Day Hub</option>
            </select>
          </div>

          <span className="text-xs text-slate-400 ml-auto">
            {filteredConsignments.length} consignments
          </span>
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/70 dark:border-slate-800">
                <th className="py-3 px-4">AWB Number</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Route</th>
                <th className="py-3 px-4">Service & Payment</th>
                <th className="py-3 px-4">Weight / Pieces</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Booking Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredConsignments.length > 0 ? (
                filteredConsignments.map((csg) => (
                  <tr
                    key={csg.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleTrackClick(csg.awbNumber)}
                        className="font-mono font-bold text-blue-600 dark:text-cyan-400 hover:underline flex items-center gap-1 group"
                        title="Click to track shipment"
                      >
                        <span>{csg.awbNumber}</span>
                        <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                      <p>{csg.customerName}</p>
                      <p className="text-[11px] text-slate-400 font-normal">To: {csg.recipientName}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                      <span className="font-semibold">{csg.fromCity}</span>
                      <span className="text-slate-400 mx-1">→</span>
                      <span className="font-semibold text-blue-600 dark:text-cyan-400">{csg.toCity}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800 dark:text-slate-200 block">{csg.serviceType}</span>
                      <span className="text-[10px] text-slate-400">{csg.paymentType}</span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-700 dark:text-slate-300">
                      {csg.weight} kg <span className="text-slate-400 text-[11px]">({csg.pieces} pcs)</span>
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={csg.status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      {csg.bookingDate}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenStatusModal(csg)}
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors"
                          title="Update Status"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setPrintPreviewCsg(csg)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg transition-colors"
                          title="Print Note"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleTrackClick(csg.awbNumber)}
                          className="p-1.5 text-slate-500 hover:text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 rounded-lg transition-colors"
                          title="Live Tracking"
                        >
                          <Compass className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(csg)}
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Delete Consignment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Boxes className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-600 dark:text-slate-400">No consignments found</p>
                    <p className="text-xs text-slate-400 mt-1">Try changing your filters or create a new consignment.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* UPDATE STATUS MODAL */}
      <Modal
        isOpen={!!statusUpdateTarget}
        onClose={() => setStatusUpdateTarget(null)}
        title="Update Consignment Status"
        subtitle={`AWB: ${statusUpdateTarget?.awbNumber}`}
        maxWidth="md"
      >
        <form onSubmit={handleSaveStatus} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Select New Status
            </label>
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as ShipmentStatus)}
              className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              <option value="Booked">Booked</option>
              <option value="Picked Up">Picked Up</option>
              <option value="In Transit">In Transit</option>
              <option value="Arrived at Hub">Arrived at Hub</option>
              <option value="Out for Delivery">Out for Delivery</option>
              <option value="Delivered">Delivered</option>
              <option value="Pending">Pending (Exception)</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Current Location / Hub Station
            </label>
            <input
              type="text"
              value={newLocation}
              onChange={(e) => setNewLocation(e.target.value)}
              placeholder="e.g. Delhi Central Sorting Hub"
              className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            />
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setStatusUpdateTarget(null)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors"
            >
              Apply Status Update
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT PREVIEW MODAL */}
      <Modal
        isOpen={!!printPreviewCsg}
        onClose={() => setPrintPreviewCsg(null)}
        title="Consignment Note / Delivery Run Sheet"
        subtitle={`Official Air Waybill Document: ${printPreviewCsg?.awbNumber}`}
        maxWidth="2xl"
      >
        {printPreviewCsg && (
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 text-xs font-sans">
            {/* Header */}
            <div className="flex items-start justify-between border-b pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white">TSIBIS SOLUTION</h3>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest">INDEX EXPRESS SERVICE</p>
                <p className="text-[10px] text-slate-400">GSTIN: 07AAACT0000Z1Z4 • Customer Care: 1800-TSIBIS</p>
              </div>
              <div className="text-right">
                <span className="font-mono font-black text-lg text-blue-600 dark:text-cyan-400 block">
                  {printPreviewCsg.awbNumber}
                </span>
                <span className="text-[10px] text-slate-400">Date: {printPreviewCsg.bookingDate}</span>
              </div>
            </div>

            {/* Sender / Receiver Box */}
            <div className="grid grid-cols-2 gap-4 border p-3 rounded-lg bg-slate-50/50 dark:bg-slate-800/40">
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Consignor (Shipper)</span>
                <p className="font-bold text-slate-900 dark:text-white mt-1">{printPreviewCsg.customerName}</p>
                <p className="text-slate-500">Origin City: {printPreviewCsg.fromCity}</p>
                <p className="text-slate-500">Phone: {printPreviewCsg.senderPhone || 'N/A'}</p>
              </div>
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Consignee (Recipient)</span>
                <p className="font-bold text-slate-900 dark:text-white mt-1">{printPreviewCsg.recipientName}</p>
                <p className="text-slate-500">{printPreviewCsg.deliveryAddress}</p>
                <p className="text-slate-500">{printPreviewCsg.toCity} - {printPreviewCsg.pinCode}</p>
                <p className="text-slate-500">Phone: {printPreviewCsg.recipientPhone}</p>
              </div>
            </div>

            {/* Package details */}
            <div className="grid grid-cols-4 gap-2 text-center border p-2 rounded-lg">
              <div>
                <span className="text-[10px] text-slate-400 block">Service</span>
                <span className="font-bold">{printPreviewCsg.serviceType}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Payment Mode</span>
                <span className="font-bold">{printPreviewCsg.paymentType}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Pieces / Weight</span>
                <span className="font-bold">{printPreviewCsg.pieces} pcs / {printPreviewCsg.weight} kg</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Declared Value</span>
                <span className="font-bold">₹{printPreviewCsg.declaredValue.toLocaleString()}</span>
              </div>
            </div>

            {/* Signature row */}
            <div className="pt-6 grid grid-cols-2 gap-8 text-[11px] text-slate-400">
              <div className="border-t pt-2 text-center">
                <span>Shipper / Booking Officer Signature</span>
              </div>
              <div className="border-t pt-2 text-center">
                <span>Receiver Signature & Official Stamp</span>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Print Document</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* CONFIRM DELETE */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) deleteConsignment(deleteTarget.id);
        }}
        title={`Delete Consignment: ${deleteTarget?.awbNumber}?`}
        message="Are you sure you want to delete this consignment record? This action cannot be reversed."
      />
    </div>
  );
};
