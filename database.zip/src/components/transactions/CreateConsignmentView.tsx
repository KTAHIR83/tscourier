'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ServiceType, PaymentType, Consignment } from '@/types';
import { Modal } from '@/components/ui/Modal';
import {
  ArrowLeft,
  PackagePlus,
  RotateCcw,
  CheckCircle2,
  Printer,
  Search,
  Truck,
  IndianRupee,
  MapPin,
  User,
  ShieldAlert,
} from 'lucide-react';

export const CreateConsignmentView: React.FC = () => {
  const { customers, cities, addConsignment, setActiveNav, setQuickTrackAwb } = useApp();

  // Form states
  const [selectedCustomerId, setSelectedCustomerId] = useState(customers[0]?.id || '');
  const [customerRef, setCustomerRef] = useState('');
  const [senderPhone, setSenderPhone] = useState(customers[0]?.phone || '');

  const [fromCity, setFromCity] = useState('Delhi');
  const [toCity, setToCity] = useState('Mumbai');
  const [serviceType, setServiceType] = useState<ServiceType>('Express Air');
  const [paymentType, setPaymentType] = useState<PaymentType>('Paid');

  const [weight, setWeight] = useState<string>('3.5');
  const [pieces, setPieces] = useState<string>('1');
  const [declaredValue, setDeclaredValue] = useState<string>('15000');

  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [area, setArea] = useState('');
  const [pinCode, setPinCode] = useState('');

  const [notes, setNotes] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Success dialog state
  const [createdConsignment, setCreatedConsignment] = useState<Consignment | null>(null);

  // When customer changes, update contact info
  const handleCustomerChange = (cId: string) => {
    setSelectedCustomerId(cId);
    const found = customers.find((c) => c.id === cId);
    if (found) {
      setSenderPhone(found.phone);
    }
  };

  const handleReset = () => {
    setCustomerRef('');
    setWeight('3.5');
    setPieces('1');
    setDeclaredValue('15000');
    setRecipientName('');
    setRecipientPhone('');
    setDeliveryAddress('');
    setArea('');
    setPinCode('');
    setNotes('');
    setSpecialInstructions('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const customer = customers.find((c) => c.id === selectedCustomerId) || customers[0];

    const newConsignment = addConsignment({
      customerId: customer.id,
      customerName: customer.name,
      senderPhone,
      recipientName: recipientName || 'Consignee Receiver',
      recipientPhone: recipientPhone || '+91 98000 00000',
      fromCity,
      toCity,
      serviceType,
      paymentType,
      weight: parseFloat(weight) || 1.0,
      pieces: parseInt(pieces) || 1,
      declaredValue: parseFloat(declaredValue) || 1000,
      deliveryAddress: deliveryAddress || 'Destination Commercial Hub',
      area: area || 'Central Sector',
      pinCode: pinCode || '110001',
      notes,
      specialInstructions,
    });

    setCreatedConsignment(newConsignment);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <button
            onClick={() => setActiveNav('transactions-consignments')}
            className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Consignments List</span>
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-cyan-400 flex items-center justify-center">
              <PackagePlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Transaction — Create Consignment
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Book express freight, assign routing parameters, and print official AWB
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-xs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Form</span>
        </button>
      </div>

      {/* MULTI-SECTION BOOKING FORM (Matches screenshot card structure!) */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Customer Details */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white font-bold text-sm">
            <User className="w-4 h-4 text-blue-600 dark:text-cyan-400" />
            <span>1. Customer Details (Outbound Party)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Customer *
              </label>
              <select
                value={selectedCustomerId}
                onChange={(e) => handleCustomerChange(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code}) - {c.city}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Sender Contact Phone
              </label>
              <input
                type="text"
                value={senderPhone}
                onChange={(e) => setSenderPhone(e.target.value)}
                placeholder="+91 98100 00000"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Shipper Invoice / Reference No.
              </label>
              <input
                type="text"
                value={customerRef}
                onChange={(e) => setCustomerRef(e.target.value)}
                placeholder="e.g. INV-2025-8841"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Shipment & Logistics Details */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white font-bold text-sm">
            <Truck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>2. Shipment & Routing Details</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                From City *
              </label>
              <select
                value={fromCity}
                onChange={(e) => setFromCity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {cities.map((ct) => (
                  <option key={ct.id} value={ct.cityName}>{ct.cityName} ({ct.state})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                To City (Destination) *
              </label>
              <select
                value={toCity}
                onChange={(e) => setToCity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                {cities.map((ct) => (
                  <option key={ct.id} value={ct.cityName}>{ct.cityName} ({ct.state})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Service Type *
              </label>
              <select
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value as ServiceType)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="Express Air">Express Air (Fastest)</option>
                <option value="Surface Cargo">Surface Cargo (Heavy Freight)</option>
                <option value="Standard Express">Standard Express (Economy)</option>
                <option value="Same Day Hub">Same Day Hub (Intra-city)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Payment Type *
              </label>
              <select
                value={paymentType}
                onChange={(e) => setPaymentType(e.target.value as PaymentType)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="Paid">Paid (Cash/Online)</option>
                <option value="To-Pay">To-Pay (Collect from Consignee)</option>
                <option value="TBB (To-Be-Billed)">TBB (Monthly Account Invoice)</option>
                <option value="COD">COD (Cash on Delivery)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 3: Package Specifications */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white font-bold text-sm">
            <IndianRupee className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span>3. Package & Tariff Specifications</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Chargeable Weight (kg) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                required
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="e.g. 4.5"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Total Pieces / Boxes *
              </label>
              <input
                type="number"
                min="1"
                required
                value={pieces}
                onChange={(e) => setPieces(e.target.value)}
                placeholder="e.g. 2"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Declared Goods Value (₹) *
              </label>
              <input
                type="number"
                min="100"
                required
                value={declaredValue}
                onChange={(e) => setDeclaredValue(e.target.value)}
                placeholder="e.g. 25000"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Delivery / Consignee Address */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white font-bold text-sm">
            <MapPin className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
            <span>4. Delivery & Consignee Information</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Recipient Contact Name *
              </label>
              <input
                type="text"
                required
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="e.g. Rajesh Khurana"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Recipient Phone Number *
              </label>
              <input
                type="tel"
                required
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Delivery Address *
              </label>
              <input
                type="text"
                required
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                placeholder="Shop / Building / Street address"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                PIN Code *
              </label>
              <input
                type="text"
                required
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                placeholder="e.g. 110020"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>
        </div>

        {/* Section 5: Additional Notes */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white font-bold text-sm">
            <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>5. Operational Instructions & Handling Notes</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Handling Notes (e.g. Fragile, Keep Upright)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Handle with care, electronic equipment"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Special Delivery Instructions
              </label>
              <input
                type="text"
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="e.g. Call before delivery attempt"
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons Bar */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={handleReset}
            className="px-5 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
          >
            Reset
          </button>
          <button
            type="submit"
            className="px-6 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Create Consignment</span>
          </button>
        </div>
      </form>

      {/* CREATION SUCCESS MODAL */}
      <Modal
        isOpen={!!createdConsignment}
        onClose={() => setCreatedConsignment(null)}
        title="Consignment Booked Successfully!"
        subtitle="Air Waybill (AWB) generated in system"
        maxWidth="lg"
      >
        {createdConsignment && (
          <div className="space-y-5 text-center">
            {/* AWB Highlight Box */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800/80 border border-blue-100 dark:border-slate-700">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Consignment AWB Number
              </span>
              <h3 className="text-3xl font-black font-mono text-blue-600 dark:text-cyan-400 mt-1">
                {createdConsignment.awbNumber}
              </h3>

              {/* Barcode simulation */}
              <div className="mt-4 flex flex-col items-center">
                <div className="h-10 w-48 flex items-center justify-between px-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded">
                  {Array.from({ length: 32 }).map((_, i) => (
                    <div
                      key={i}
                      className="bg-black dark:bg-white h-7"
                      style={{
                        width: i % 3 === 0 ? '3px' : i % 2 === 0 ? '1px' : '2px',
                      }}
                    />
                  ))}
                </div>
                <span className="text-[10px] font-mono text-slate-400 mt-1">
                  *{createdConsignment.awbNumber}*
                </span>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2 text-xs pt-4 border-t border-blue-200/50 dark:border-slate-700">
                <div>
                  <span className="text-slate-400 text-[10px] block">Customer</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{createdConsignment.customerName}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Route</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{createdConsignment.fromCity} → {createdConsignment.toCity}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Weight / Pcs</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{createdConsignment.weight} kg ({createdConsignment.pieces} pcs)</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Consignment Note</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setQuickTrackAwb(createdConsignment.awbNumber);
                  setActiveNav('transactions-tracking');
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl text-white bg-blue-600 hover:bg-blue-700 transition-colors"
              >
                <Search className="w-4 h-4" />
                <span>Track This Shipment</span>
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
