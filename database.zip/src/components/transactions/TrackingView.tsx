'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { sampleTrackingEvents } from '@/data/mockData';
import { TrackingEvent, ShipmentStatus } from '@/types';
import {
  Search,
  Truck,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Building,
  User,
  ArrowRight,
  ShieldCheck,
  Package,
} from 'lucide-react';

export const TrackingView: React.FC = () => {
  const { consignments, quickTrackAwb, setQuickTrackAwb } = useApp();

  const [inputAwb, setInputAwb] = useState<string>(quickTrackAwb || 'TSB00004587');
  const [activeAwb, setActiveAwb] = useState<string>(quickTrackAwb || 'TSB00004587');

  useEffect(() => {
    if (quickTrackAwb) {
      setInputAwb(quickTrackAwb);
      setActiveAwb(quickTrackAwb);
    }
  }, [quickTrackAwb]);

  const currentConsignment = consignments.find(
    (c) => c.awbNumber.toLowerCase() === activeAwb.trim().toLowerCase()
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputAwb.trim()) return;
    setActiveAwb(inputAwb.trim());
    setQuickTrackAwb(inputAwb.trim());
  };

  const stepsOrder: ShipmentStatus[] = [
    'Booked',
    'Picked Up',
    'In Transit',
    'Arrived at Hub',
    'Out for Delivery',
    'Delivered',
  ];

  const getStepIndex = (status: ShipmentStatus) => {
    const idx = stepsOrder.indexOf(status);
    return idx === -1 ? 2 : idx; // fallback
  };

  const currentStepIndex = currentConsignment
    ? getStepIndex(currentConsignment.status)
    : 5;

  // Custom or synthesized tracking events
  const trackingEvents: TrackingEvent[] =
    sampleTrackingEvents[activeAwb] ||
    (currentConsignment
      ? [
          {
            timestamp: currentConsignment.bookingDate,
            location: `${currentConsignment.fromCity} Origin Booking Station`,
            status: 'Booked',
            description: `Consignment booked by ${currentConsignment.customerName} via ${currentConsignment.serviceType}`,
          },
          {
            timestamp: `${currentConsignment.bookingDate.split(' ')[0]} 14:00`,
            location: `${currentConsignment.fromCity} Central Hub`,
            status: 'Picked Up',
            description: `Package picked up, weighed (${currentConsignment.weight}kg), barcoded`,
          },
          ...(currentStepIndex >= 2
            ? [
                {
                  timestamp: `${currentConsignment.bookingDate.split(' ')[0]} 20:30`,
                  location: `Express Corridor / Highway Checkpoint`,
                  status: 'In Transit' as ShipmentStatus,
                  description: `Consolidated in line-haul manifest en route to ${currentConsignment.toCity}`,
                },
              ]
            : []),
          ...(currentStepIndex >= 3
            ? [
                {
                  timestamp: `${currentConsignment.bookingDate.split(' ')[0]} 06:15`,
                  location: `${currentConsignment.toCity} Mother Hub`,
                  status: 'Arrived at Hub' as ShipmentStatus,
                  description: `Inbound scan completed at ${currentConsignment.toCity} hub`,
                },
              ]
            : []),
          ...(currentStepIndex >= 4
            ? [
                {
                  timestamp: `${currentConsignment.bookingDate.split(' ')[0]} 09:30`,
                  location: `${currentConsignment.area} Delivery Station`,
                  status: 'Out for Delivery' as ShipmentStatus,
                  description: `Assigned to delivery route van for ${currentConsignment.recipientName}`,
                },
              ]
            : []),
          ...(currentStepIndex >= 5
            ? [
                {
                  timestamp: currentConsignment.deliveredDate || '2025-08-25 14:15',
                  location: currentConsignment.deliveryAddress,
                  status: 'Delivered' as ShipmentStatus,
                  description: `Delivered to recipient. Signature verified.`,
                },
              ]
            : []),
        ]
      : []);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Shipment Tracking & Timeline
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time status milestones and checkpoint audit trail
          </p>
        </div>
      </div>

      {/* TRACKING SEARCH BAR */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Enter AWB / Consignment Number (e.g. TSB00004587)"
              value={inputAwb}
              onChange={(e) => setInputAwb(e.target.value)}
              className="w-full pl-11 pr-4 py-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono font-medium"
            />
          </div>

          <button
            type="submit"
            className="px-6 py-3 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            <span>Track Shipment</span>
          </button>
        </form>

        {/* Quick Suggestion Pills */}
        <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">Quick Test AWBs:</span>
          {consignments.slice(0, 4).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setInputAwb(c.awbNumber);
                setActiveAwb(c.awbNumber);
              }}
              className={`font-mono px-2.5 py-1 rounded-lg border transition-colors ${
                activeAwb === c.awbNumber
                  ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-cyan-400 border-blue-200 dark:border-blue-800 font-bold'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
              }`}
            >
              {c.awbNumber} ({c.toCity})
            </button>
          ))}
        </div>
      </div>

      {currentConsignment ? (
        <div className="space-y-6">
          {/* SHIPMENT SUMMARY CARD */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-black font-mono text-slate-900 dark:text-white">
                    {currentConsignment.awbNumber}
                  </span>
                  <StatusBadge status={currentConsignment.status} size="md" />
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Booked on {currentConsignment.bookingDate} • {currentConsignment.serviceType}
                </p>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Estimated SLA</span>
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">On Schedule (Guaranteed)</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Current Location</span>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">{currentConsignment.currentLocation}</span>
                </div>
              </div>
            </div>

            {/* Origin -> Destination corridor banner */}
            <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-400 text-[11px] block">Origin (Consignor)</span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">{currentConsignment.fromCity}</span>
                <span className="text-slate-500 block text-[11px]">{currentConsignment.customerName}</span>
              </div>
              <div className="sm:col-span-2 flex items-center justify-center">
                <div className="w-full flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                  <div className="flex-1 border-t-2 border-dashed border-blue-300 dark:border-blue-700 relative">
                    <Truck className="w-4 h-4 text-blue-600 dark:text-cyan-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-slate-800 px-0.5" />
                  </div>
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
              </div>
              <div className="text-right">
                <span className="text-slate-400 text-[11px] block">Destination (Consignee)</span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">{currentConsignment.toCity}</span>
                <span className="text-slate-500 block text-[11px]">{currentConsignment.recipientName}</span>
              </div>
            </div>
          </div>

          {/* HORIZONTAL STEPPER (Prompt requirement: Booked -> Picked Up -> In Transit -> Arrived at Hub -> Out for Delivery -> Delivered) */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-6">
              Milestone Progress
            </h3>

            <div className="relative">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {stepsOrder.map((step, idx) => {
                  const isDone = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex;

                  return (
                    <div
                      key={step}
                      className={`p-3 rounded-xl border flex flex-col items-center text-center transition-all ${
                        isCurrent
                          ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-400 text-blue-700 dark:text-blue-300 font-bold shadow-xs'
                          : isDone
                          ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40 text-emerald-700 dark:text-emerald-400'
                          : 'bg-slate-50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 text-slate-400'
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${
                          isCurrent
                            ? 'bg-blue-600 text-white shadow-sm ring-4 ring-blue-100 dark:ring-blue-900'
                            : isDone
                            ? 'bg-emerald-500 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                      </div>
                      <span className="text-xs font-semibold">{step}</span>
                      <span className="text-[10px] mt-0.5 text-slate-400">
                        {isCurrent ? 'Active Stage' : isDone ? 'Completed' : 'Pending'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* DETAILED VERTICAL AUDIT TIMELINE */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-6">
              Activity History & Scan Log
            </h3>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
              {trackingEvents.map((evt, idx) => (
                <div key={idx} className="relative group">
                  {/* Timeline Node Dot */}
                  <div
                    className={`absolute -left-6 top-1 w-3.5 h-3.5 rounded-full border-2 bg-white dark:bg-slate-900 transition-colors ${
                      idx === trackingEvents.length - 1
                        ? 'border-emerald-500 ring-4 ring-emerald-100 dark:ring-emerald-950'
                        : 'border-blue-500'
                    }`}
                  />

                  <div className="bg-slate-50/70 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/60">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 dark:text-white">
                          {evt.status}
                        </span>
                        <span className="text-slate-300 dark:text-slate-600">•</span>
                        <span className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1 font-medium">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {evt.location}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">
                        {evt.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {evt.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-center">
          <Package className="w-12 h-12 mx-auto text-slate-300 mb-3" />
          <h4 className="text-base font-bold text-slate-700 dark:text-slate-300">
            No Consignment Found with AWB &quot;{activeAwb}&quot;
          </h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
            Please verify the Air Waybill number or select one from the recent consignments register.
          </p>
        </div>
      )}
    </div>
  );
};
