'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { StatusBadge } from '@/components/ui/StatusBadge';
import {
  FileText,
  Calendar,
  Filter,
  Download,
  Printer,
  PieChart as PieIcon,
  TrendingUp,
  Boxes,
  Truck,
  CheckCircle2,
  Clock,
  ArrowRight,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

export const ReportsView: React.FC = () => {
  const { consignments, customers, cities, setActiveNav, setQuickTrackAwb } = useApp();

  const [activeTab, setActiveTab] = useState<
    'consignments' | 'delivery' | 'customers' | 'manifest' | 'tax' | 'financial'
  >('consignments');

  const [fromDate, setFromDate] = useState('2025-08-01');
  const [toDate, setToDate] = useState('2025-08-25');
  const [selectedCustomer, setSelectedCustomer] = useState('All');
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  // Filtered dataset
  const filteredData = consignments.filter((c) => {
    const matchesCustomer = selectedCustomer === 'All' || c.customerName === selectedCustomer;
    const matchesCity = selectedCity === 'All' || c.toCity === selectedCity || c.fromCity === selectedCity;
    const matchesStatus = selectedStatus === 'All' || c.status === selectedStatus;
    return matchesCustomer && matchesCity && matchesStatus;
  });

  // Calculate totals
  const totalShipments = 8942;
  const deliveredCount = 7856;
  const inTransitCount = 1284;
  const pendingCount = 428;

  // Pie chart data
  const pieData = [
    { name: 'Delivered', value: deliveredCount, color: '#10B981', percentage: '87.8%' },
    { name: 'In Transit', value: inTransitCount, color: '#3B82F6', percentage: '14.3%' },
    { name: 'Pending', value: pendingCount, color: '#F59E0B', percentage: '4.8%' },
  ];

  const handleExportPDF = () => {
    window.print();
  };

  const handleExportExcel = () => {
    const headers = ['AWB No,Customer,Origin,Destination,Service,Payment,Weight (kg),Declared Value (INR),Status,Date'];
    const rows = filteredData.map(
      (c) => `"${c.awbNumber}","${c.customerName}","${c.fromCity}","${c.toCity}","${c.serviceType}","${c.paymentType}",${c.weight},${c.declaredValue},"${c.status}","${c.bookingDate}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TSIBIS_Report_${activeTab}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* HEADER & FILTER BAR (Matches screenshot!) */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Reports
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              View and export your shipment data across operations & financials
            </p>
          </div>

          {/* Sub-report tab switches */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
            {[
              { id: 'consignments', label: 'Consignments' },
              { id: 'delivery', label: 'Delivery Performance' },
              { id: 'customers', label: 'Customer Billing' },
              { id: 'manifest', label: 'Manifest Reconciliation' },
              { id: 'tax', label: 'Tax / GST' },
              { id: 'financial', label: 'Financial' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === tab.id
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-cyan-300 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Date Filter & Selector bar */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 items-end text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              From Date
            </label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              To Date
            </label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Customer
            </label>
            <select
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Customers</option>
              {customers.map((c) => (
                <option key={c.id} value={c.name}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Destination City
            </label>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="All">All Cities</option>
              {cities.map((ct) => (
                <option key={ct.id} value={ct.cityName}>{ct.cityName}</option>
              ))}
            </select>
          </div>

          <div>
            <button
              type="button"
              className="w-full py-2 px-4 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Generate</span>
            </button>
          </div>
        </div>
      </div>

      {/* TOP SUMMARY KPI PILLS (Matches screenshot!) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-cyan-400 flex items-center justify-center">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Shipments</span>
            <p className="text-xl font-black text-slate-900 dark:text-white">{totalShipments.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Delivered</span>
            <p className="text-xl font-black text-emerald-600 dark:text-emerald-400">{deliveredCount.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase">In Transit</span>
            <p className="text-xl font-black text-blue-600 dark:text-blue-400">{inTransitCount.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Pending</span>
            <p className="text-xl font-black text-amber-600 dark:text-amber-400">{pendingCount.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* VISUAL CHARTS & EXPORT SECTION (Matches screenshot donut + export buttons!) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Shipment Status Donut Chart */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-blue-600 dark:text-cyan-400" />
              <span>Shipment Status Breakdown</span>
            </h3>
            <span className="text-xs text-slate-400">Total: 8,942 Shipments</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 items-center gap-4 py-4">
            {/* Donut chart */}
            <div className="sm:col-span-6 h-56 relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={90}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '12px',
                      color: '#FFF',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              {/* Center donut label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-black text-slate-900 dark:text-white">8,942</span>
                <span className="text-[10px] text-slate-400 uppercase tracking-widest">Total</span>
              </div>
            </div>

            {/* Legend pills */}
            <div className="sm:col-span-6 space-y-3">
              {pieData.map((p) => (
                <div
                  key={p.name}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: p.color }}
                    />
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      {p.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {p.value.toLocaleString()}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">
                      {p.percentage}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Export Report Box (Red & Green download buttons matching screenshot!) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              Export Report
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 leading-relaxed">
              Export complete transaction ledgers, delivery run-sheets, and customer accounts in official printable PDF format or Microsoft Excel spreadsheet.
            </p>
          </div>

          <div className="space-y-3 mt-6">
            <button
              onClick={handleExportPDF}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 shadow-md shadow-rose-600/20 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>

            <button
              onClick={handleExportExcel}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 shadow-md shadow-emerald-600/20 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* REPORT DATA TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Detailed Report Register ({filteredData.length} records)
          </h3>
          <span className="text-xs text-slate-400">Date Range: {fromDate} to {toDate}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/70 dark:border-slate-800">
                <th className="py-3 px-4">AWB No.</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Origin / Dest</th>
                <th className="py-3 px-4">Weight / Pcs</th>
                <th className="py-3 px-4">Declared Value</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredData.map((c) => (
                <tr
                  key={c.id}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer"
                  onClick={() => {
                    setQuickTrackAwb(c.awbNumber);
                    setActiveNav('transactions-tracking');
                  }}
                >
                  <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">
                    {c.awbNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                    {c.customerName}
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    {c.fromCity} → <span className="font-semibold text-blue-600 dark:text-cyan-400">{c.toCity}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">
                    {c.weight} kg ({c.pieces} pcs)
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                    ₹{c.declaredValue.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <StatusBadge status={c.status} size="sm" />
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400 whitespace-nowrap">
                    {c.bookingDate.split(' ')[0]}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
