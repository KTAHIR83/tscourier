'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Modal } from '@/components/ui/Modal';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import {
  ArrowLeft,
  Plus,
  Search,
  Download,
  Trash2,
  Edit2,
  Layers,
  Compass,
  Truck,
  Briefcase,
  Building2,
  Radio,
  Boxes,
  Receipt,
  Share2,
} from 'lucide-react';

interface GenericMasterViewProps {
  type:
    | 'areas'
    | 'slabs'
    | 'routes'
    | 'employees'
    | 'manifest-companies'
    | 'stations'
    | 'loaders'
    | 'tax'
    | 'suppliers';
}

export const GenericMasterView: React.FC<GenericMasterViewProps> = ({ type }) => {
  const {
    areas,
    addArea,
    deleteArea,
    slabs,
    addSlab,
    updateSlab,
    deleteSlab,
    routes,
    addRoute,
    deleteRoute,
    employees,
    addEmployee,
    deleteEmployee,
    manifestCompanies,
    addManifestCompany,
    deleteManifestCompany,
    stations,
    addStation,
    deleteStation,
    loaders,
    addLoader,
    deleteLoader,
    taxEntries,
    addTaxEntry,
    deleteTaxEntry,
    suppliers,
    addSupplier,
    deleteSupplier,
    setActiveNav,
  } = useApp();

  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  // Generic form fields
  const [field1, setField1] = useState('');
  const [field2, setField2] = useState('');
  const [field3, setField3] = useState('');
  const [field4, setField4] = useState('');
  const [field5, setField5] = useState('');
  const [fieldExtraRate, setFieldExtraRate] = useState('50');
  const [fieldService, setFieldService] = useState<'Express Air' | 'Surface Cargo' | 'Standard Express' | 'Same Day Hub'>('Express Air');
  const [fieldStatus, setFieldStatus] = useState<'Active' | 'Inactive'>('Active');

  // Configuration for each master type
  const config = {
    areas: {
      title: 'Area Master Entry',
      subtitle: 'Manage local delivery sectors, pin mapping, and assigned delivery hubs',
      icon: Compass,
      columns: ['Area Name', 'City', 'State', 'PIN Code', 'Delivery Hub', 'Status'],
      data: areas,
      searchFields: (item: any) => `${item.areaName} ${item.cityName} ${item.pinCode}`,
      formLabels: ['Area Name *', 'City Name *', 'State *', 'PIN Code', 'Delivery Hub'],
      onAdd: () => {
        addArea({
          areaName: field1,
          cityName: field2,
          state: field3,
          pinCode: field4,
          deliveryHub: field5 || 'Central Hub',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteArea(id),
    },
    slabs: {
      title: 'Slab Master Rates',
      subtitle: 'Configure tariff weight brackets, base freight, and incremental rates per kg',
      icon: Layers,
      columns: ['Slab Code', 'Slab Name', 'Service Type', 'Weight Range', 'Base Rate', 'Extra / kg', 'Status'],
      data: slabs,
      searchFields: (item: any) => `${item.slabCode} ${item.slabName} ${item.serviceType}`,
      formLabels: ['Slab Code (e.g. SLB-AIR-01)', 'Slab Name *', 'Min Weight (kg)', 'Max Weight (kg)', 'Base Rate (₹)'],
      onAdd: () => {
        addSlab({
          slabCode: field1 || `SLB-${Date.now().toString().slice(-4)}`,
          slabName: field2,
          serviceType: fieldService,
          minWeightKg: Number(field3) || 0,
          maxWeightKg: Number(field4) || 5,
          baseRate: Number(field5) || 200,
          extraRatePerKg: Number(fieldExtraRate) || 50,
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteSlab(id),
    },
    routes: {
      title: 'Route Master Operations',
      subtitle: 'Logistics transit corridors, transit day commitments, and distance tracking',
      icon: Truck,
      columns: ['Route Code', 'Origin City', 'Destination City', 'Via Checkpoints', 'Distance (km)', 'Transit SLA', 'Status'],
      data: routes,
      searchFields: (item: any) => `${item.routeCode} ${item.originCity} ${item.destinationCity}`,
      formLabels: ['Route Code (e.g. RT-DEL-BLR)', 'Origin City *', 'Destination City *', 'Distance (km)', 'Standard Transit Days'],
      onAdd: () => {
        addRoute({
          routeCode: field1 || `RT-${field2.slice(0, 3)}-${field3.slice(0, 3)}`.toUpperCase(),
          originCity: field2,
          destinationCity: field3,
          viaCities: ['Express Corridor'],
          distanceKm: Number(field4) || 500,
          standardTransitDays: Number(field5) || 2,
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteRoute(id),
    },
    employees: {
      title: 'Employee Master',
      subtitle: 'Staff registry, departmental allocations, branch assignments, and contacts',
      icon: Briefcase,
      columns: ['Emp Code', 'Employee Name', 'Department', 'Designation', 'Branch', 'Phone', 'Status'],
      data: employees,
      searchFields: (item: any) => `${item.empCode} ${item.name} ${item.department} ${item.phone}`,
      formLabels: ['Emp Code (e.g. EMP-0106)', 'Full Name *', 'Department *', 'Designation', 'Branch'],
      onAdd: () => {
        addEmployee({
          empCode: field1 || `EMP-0${employees.length + 105}`,
          name: field2,
          department: (field3 as any) || 'Operations',
          designation: field4 || 'Executive',
          branch: field5 || 'Central Hub',
          phone: '+91 98000 00000',
          email: `${field2.toLowerCase().replace(/\s+/g, '.')}@tsibis.in`,
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteEmployee(id),
    },
    'manifest-companies': {
      title: 'Manifest Company Master',
      subtitle: 'Airline cargo freighters, commercial road liners, and contractual manifest partners',
      icon: Building2,
      columns: ['Company Code', 'Company Name', 'Contact Person', 'Phone', 'City', 'GSTIN', 'Status'],
      data: manifestCompanies,
      searchFields: (item: any) => `${item.companyCode} ${item.companyName} ${item.city}`,
      formLabels: ['Company Code', 'Company Name *', 'Contact Person', 'Phone', 'City'],
      onAdd: () => {
        addManifestCompany({
          companyCode: field1 || `MC-${field2.slice(0, 4).toUpperCase()}`,
          companyName: field2,
          contactPerson: field3 || 'Operations Lead',
          phone: field4 || '+91 1800 000 000',
          email: 'info@partner.com',
          city: field5 || 'Delhi',
          gstNo: '07AAACM9999M1Z9',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteManifestCompany(id),
    },
    stations: {
      title: 'Station Master',
      subtitle: 'Mother sorting hubs, regional delivery stations, and airport gateways',
      icon: Radio,
      columns: ['Station Code', 'Station Name', 'City', 'State', 'Hub Type', 'Contact', 'Status'],
      data: stations,
      searchFields: (item: any) => `${item.stationCode} ${item.stationName} ${item.city}`,
      formLabels: ['Station Code', 'Station Name *', 'City *', 'State', 'Hub Type (Mother Hub / Delivery Hub)'],
      onAdd: () => {
        addStation({
          stationCode: field1 || `ST-${field3.slice(0, 3).toUpperCase()}-DH`,
          stationName: field2,
          city: field3,
          state: field4 || 'National',
          hubType: (field5 as any) || 'Delivery Hub',
          contactPerson: 'Hub Incharge',
          phone: '+91 98000 11111',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteStation(id),
    },
    loaders: {
      title: 'Manifest Co Loaders Master',
      subtitle: 'Third-party bulk cargo loaders, co-loaders, and airport ramp handlers',
      icon: Boxes,
      columns: ['Loader Code', 'Loader Name', 'Supported Services', 'Contact Person', 'Phone', 'City', 'Status'],
      data: loaders,
      searchFields: (item: any) => `${item.loaderCode} ${item.loaderName} ${item.city}`,
      formLabels: ['Loader Code', 'Loader Name *', 'Supported Services (Air/Surface)', 'Contact Person', 'City'],
      onAdd: () => {
        addLoader({
          loaderCode: field1 || `LDR-${field2.slice(0, 4).toUpperCase()}`,
          loaderName: field2,
          supportedServices: [field3 || 'Surface Cargo'],
          contactPerson: field4 || 'Cargo Manager',
          phone: '+91 98000 22222',
          city: field5 || 'Delhi',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteLoader(id),
    },
    tax: {
      title: 'Tax Entry Master (GST)',
      subtitle: 'Freight GST tariffs, SAC/HSN codes, CGST, SGST and IGST breakdowns',
      icon: Receipt,
      columns: ['Tax Code', 'Tax Name', 'HSN / SAC Code', 'CGST %', 'SGST %', 'IGST %', 'Status'],
      data: taxEntries,
      searchFields: (item: any) => `${item.taxCode} ${item.taxName} ${item.hsnCode}`,
      formLabels: ['Tax Code', 'Tax Description *', 'HSN / SAC Code', 'CGST Rate (%)', 'IGST Rate (%)'],
      onAdd: () => {
        const igst = Number(field5) || 18;
        const cgst = Number(field4) || igst / 2;
        addTaxEntry({
          taxCode: field1 || `GST-${Date.now().toString().slice(-4)}`,
          taxName: field2,
          hsnCode: field3 || '996812',
          cgstRate: cgst,
          sgstRate: cgst,
          igstRate: igst,
          effectiveFrom: '2025-04-01',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteTaxEntry(id),
    },
    suppliers: {
      title: 'Supplier / Courier Master',
      subtitle: 'Forwarding courier lines, 3PL partners, and external tracking portals',
      icon: Share2,
      columns: ['Supplier Code', 'Courier / 3PL Name', 'Service Modes', 'Contact Person', 'Tracking Portal URL', 'Status'],
      data: suppliers,
      searchFields: (item: any) => `${item.supplierCode} ${item.courierName}`,
      formLabels: ['Supplier Code', 'Courier Company Name *', 'Service Modes (Air/Surface)', 'Contact Person', 'Tracking URL'],
      onAdd: () => {
        addSupplier({
          supplierCode: field1 || `SUP-${field2.slice(0, 4).toUpperCase()}`,
          courierName: field2,
          serviceModes: [field3 || 'Air Express'],
          trackingPortalUrl: field5 || 'https://www.track.com',
          contactPerson: field4 || 'Vendor Lead',
          phone: '+91 98000 33333',
          status: fieldStatus,
        });
      },
      onDelete: (id: string) => deleteSupplier(id),
    },
  }[type];

  const currentConfig = config;
  const filteredData = (currentConfig.data as any[]).filter((item) =>
    currentConfig.searchFields(item).toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingItem(null);
    setField1('');
    setField2('');
    setField3('');
    setField4('');
    setField5('');
    setFieldExtraRate('50');
    setFieldService('Express Air');
    setFieldStatus('Active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: any) => {
    setEditingItem(item);
    if (type === 'slabs') {
      setField1(item.slabCode || '');
      setField2(item.slabName || '');
      setFieldService(item.serviceType || 'Express Air');
      setField3(String(item.minWeightKg ?? '0.1'));
      setField4(String(item.maxWeightKg ?? '5.0'));
      setField5(String(item.baseRate ?? '250'));
      setFieldExtraRate(String(item.extraRatePerKg ?? '50'));
      setFieldStatus(item.status || 'Active');
    } else {
      setField1(item.code || item.routeCode || item.empCode || item.areaName || item.companyCode || item.stationCode || item.loaderCode || item.taxCode || item.supplierCode || '');
      setField2(item.name || item.cityName || item.originCity || item.companyName || item.stationName || item.loaderName || item.taxName || item.courierName || '');
      setField3(item.department || item.state || item.destinationCity || item.contactPerson || item.hsnCode || '');
      setField4(item.designation || item.pinCode || String(item.distanceKm || '') || item.phone || String(item.cgstRate || '') || '');
      setField5(item.branch || item.deliveryHub || String(item.standardTransitDays || '') || item.city || String(item.igstRate || '') || '');
      setFieldStatus(item.status || 'Active');
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      if (type === 'slabs') {
        updateSlab(editingItem.id, {
          slabCode: field1,
          slabName: field2,
          serviceType: fieldService,
          minWeightKg: parseFloat(field3) || 0,
          maxWeightKg: parseFloat(field4) || 5,
          baseRate: parseFloat(field5) || 200,
          extraRatePerKg: parseFloat(fieldExtraRate) || 50,
          status: fieldStatus,
        });
      }
      setEditingItem(null);
    } else {
      currentConfig.onAdd();
    }
    setIsModalOpen(false);
  };

  const exportCSV = () => {
    const headers = currentConfig.columns.join(',');
    const rows = filteredData.map((item) => Object.values(item).map((v) => `"${v}"`).join(','));
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TSIBIS_${type}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const Icon = currentConfig.icon;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <button
            onClick={() => setActiveNav('master-overview')}
            className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Master Management</span>
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-cyan-400 flex items-center justify-center">
              <Icon className="w-4 h-4" />
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {currentConfig.title}
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {currentConfig.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl text-white bg-blue-600 hover:bg-blue-700 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Record</span>
          </button>
        </div>
      </div>

      {/* SEARCH BAR */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={`Search ${type}...`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40"
          />
        </div>
        <span className="text-xs text-slate-400">
          {filteredData.length} records available
        </span>
      </div>

      {/* TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200/70 dark:border-slate-800">
                {currentConfig.columns.map((col, idx) => (
                  <th key={idx} className="py-3 px-4">
                    {col}
                  </th>
                ))}
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredData.length > 0 ? (
                filteredData.map((item: any) => {
                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      {/* Render columns based on type */}
                      {type === 'areas' && (
                        <>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.areaName}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.cityName}</td>
                          <td className="py-3 px-4 text-slate-500">{item.state}</td>
                          <td className="py-3 px-4 font-mono">{item.pinCode}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.deliveryHub}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'slabs' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.slabCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.slabName}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">{item.serviceType}</td>
                          <td className="py-3 px-4 font-medium">{item.minWeightKg} - {item.maxWeightKg} kg</td>
                          <td className="py-3 px-4 font-bold text-emerald-600 dark:text-emerald-400">₹{item.baseRate}</td>
                          <td className="py-3 px-4 text-slate-500">+₹{item.extraRatePerKg}/kg</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'routes' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.routeCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.originCity}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.destinationCity}</td>
                          <td className="py-3 px-4 text-slate-500 text-[11px]">{Array.isArray(item.viaCities) ? item.viaCities.join(', ') : item.viaCities}</td>
                          <td className="py-3 px-4 font-mono">{item.distanceKm} km</td>
                          <td className="py-3 px-4 font-semibold text-blue-600">{item.standardTransitDays} Day(s)</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'employees' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.empCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.name}</td>
                          <td className="py-3 px-4"><span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">{item.department}</span></td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.designation}</td>
                          <td className="py-3 px-4 text-slate-500">{item.branch}</td>
                          <td className="py-3 px-4 text-slate-400">{item.phone}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'manifest-companies' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.companyCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.companyName}</td>
                          <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{item.contactPerson}</td>
                          <td className="py-3 px-4 text-slate-500">{item.phone}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.city}</td>
                          <td className="py-3 px-4 font-mono text-[11px] text-slate-500">{item.gstNo}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'stations' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.stationCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.stationName}</td>
                          <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{item.city}</td>
                          <td className="py-3 px-4 text-slate-500">{item.state}</td>
                          <td className="py-3 px-4"><span className="px-2 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/40 text-cyan-700 dark:text-cyan-300 font-medium">{item.hubType}</span></td>
                          <td className="py-3 px-4 text-slate-400">{item.phone}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'loaders' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.loaderCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.loaderName}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{Array.isArray(item.supportedServices) ? item.supportedServices.join(', ') : item.supportedServices}</td>
                          <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{item.contactPerson}</td>
                          <td className="py-3 px-4 text-slate-500">{item.phone}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.city}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'tax' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.taxCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.taxName}</td>
                          <td className="py-3 px-4 font-mono">{item.hsnCode}</td>
                          <td className="py-3 px-4 font-medium">{item.cgstRate}%</td>
                          <td className="py-3 px-4 font-medium">{item.sgstRate}%</td>
                          <td className="py-3 px-4 font-bold text-blue-600">{item.igstRate}%</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      {type === 'suppliers' && (
                        <>
                          <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400">{item.supplierCode}</td>
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{item.courierName}</td>
                          <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{Array.isArray(item.serviceModes) ? item.serviceModes.join(', ') : item.serviceModes}</td>
                          <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{item.contactPerson}</td>
                          <td className="py-3 px-4 font-mono text-[11px] text-blue-500 truncate max-w-xs">{item.trackingPortalUrl}</td>
                          <td className="py-3 px-4"><StatusBadge status={item.status} size="sm" /></td>
                        </>
                      )}

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg transition-colors"
                            title="Edit Record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteTarget({ id: item.id, name: item.name || item.cityName || item.slabName || item.routeCode || item.companyName || item.stationName || item.loaderName || item.taxName || item.courierName || 'Record' })}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                            title="Delete Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={currentConfig.columns.length + 1} className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-slate-600 dark:text-slate-400">No records found</p>
                    <p className="text-xs text-slate-400 mt-1">Try adjusting your search criteria or create a new entry.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT MODAL */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? `Edit ${currentConfig.title}` : `Add ${currentConfig.title}`}
        subtitle={editingItem ? 'Update configuration parameters and rates' : 'Create a new master entry in the logistics database'}
        maxWidth="md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {type === 'slabs' ? (
            /* SPECIALIZED SLAB MASTER RATES FORM */
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Slab Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={field1}
                    onChange={(e) => setField1(e.target.value)}
                    placeholder="e.g. SLB-AIR-01"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Service Type
                  </label>
                  <select
                    value={fieldService}
                    onChange={(e) => setFieldService(e.target.value as any)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  >
                    <option value="Express Air">Express Air</option>
                    <option value="Surface Cargo">Surface Cargo</option>
                    <option value="Standard Express">Standard Express</option>
                    <option value="Same Day Hub">Same Day Hub</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Slab Title / Description *
                </label>
                <input
                  type="text"
                  required
                  value={field2}
                  onChange={(e) => setField2(e.target.value)}
                  placeholder="e.g. Express Air Parcel (0.5 - 5kg)"
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Min Weight (kg) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={field3}
                    onChange={(e) => setField3(e.target.value)}
                    placeholder="0.1"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Max Weight (kg) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={field4}
                    onChange={(e) => setField4(e.target.value)}
                    placeholder="5.0"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Base Tariff Rate (₹) *
                  </label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={field5}
                    onChange={(e) => setField5(e.target.value)}
                    placeholder="350"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Extra Rate / kg (₹) *
                  </label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={fieldExtraRate}
                    onChange={(e) => setFieldExtraRate(e.target.value)}
                    placeholder="75"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Status
                </label>
                <select
                  value={fieldStatus}
                  onChange={(e) => setFieldStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                >
                  <option value="Active">Active (Apply to Bookings)</option>
                  <option value="Inactive">Inactive (Suspended)</option>
                </select>
              </div>
            </>
          ) : (
            /* GENERIC DEFAULT FORM */
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {currentConfig.formLabels[0]}
                </label>
                <input
                  type="text"
                  value={field1}
                  onChange={(e) => setField1(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {currentConfig.formLabels[1]}
                </label>
                <input
                  type="text"
                  required
                  value={field2}
                  onChange={(e) => setField2(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {currentConfig.formLabels[2]}
                </label>
                <input
                  type="text"
                  value={field3}
                  onChange={(e) => setField3(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {currentConfig.formLabels[3]}
                  </label>
                  <input
                    type="text"
                    value={field4}
                    onChange={(e) => setField4(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {currentConfig.formLabels[4]}
                  </label>
                  <input
                    type="text"
                    value={field5}
                    onChange={(e) => setField5(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>
              </div>
            </>
          )}

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors"
            >
              {editingItem ? 'Save Changes' : 'Save Record'}
            </button>
          </div>
        </form>
      </Modal>

      {/* CONFIRM DELETE */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) currentConfig.onDelete(deleteTarget.id);
        }}
        title={`Delete: ${deleteTarget?.name}?`}
        message="Are you sure you want to permanently delete this master record? This action cannot be reversed."
      />
    </div>
  );
};
