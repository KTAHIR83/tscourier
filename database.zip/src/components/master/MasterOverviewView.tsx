'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { masterHubMetrics } from '@/data/mockData';
import { ActiveNav } from '@/types';
import {
  Users,
  MapPin,
  Compass,
  Layers,
  Truck,
  Briefcase,
  Building2,
  Radio,
  Boxes,
  Receipt,
  Share2,
  ArrowRight,
  Plus,
} from 'lucide-react';

interface MasterCardItem {
  id: ActiveNav;
  title: string;
  count: number;
  description: string;
  icon: any;
  colorScheme: {
    bgIcon: string;
    border: string;
    accent: string;
  };
}

export const MasterOverviewView: React.FC = () => {
  const { setActiveNav, customers, cities, areas, slabs, routes, employees, manifestCompanies, stations, loaders, taxEntries, suppliers } = useApp();

  const masterCards: MasterCardItem[] = [
    {
      id: 'master-customers',
      title: 'Customers',
      count: masterHubMetrics.customers + (customers.length - 7),
      description: 'Outbound party accounts, GST & credit profiles',
      icon: Users,
      colorScheme: {
        bgIcon: 'bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400',
        border: 'border-blue-100 dark:border-blue-900/30',
        accent: 'text-blue-600 dark:text-blue-400',
      },
    },
    {
      id: 'master-cities',
      title: 'Cities',
      count: masterHubMetrics.cities + (cities.length - 12),
      description: 'Operational hubs, PIN codes & state mapping',
      icon: MapPin,
      colorScheme: {
        bgIcon: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400',
        border: 'border-emerald-100 dark:border-emerald-900/30',
        accent: 'text-emerald-600 dark:text-emerald-400',
      },
    },
    {
      id: 'master-areas',
      title: 'Areas',
      count: masterHubMetrics.areas + (areas.length - 8),
      description: 'Local delivery zones and sub-pin sector clusters',
      icon: Compass,
      colorScheme: {
        bgIcon: 'bg-amber-50 text-amber-600 dark:bg-amber-950/50 dark:text-amber-400',
        border: 'border-amber-100 dark:border-amber-900/30',
        accent: 'text-amber-600 dark:text-amber-400',
      },
    },
    {
      id: 'master-slabs',
      title: 'Slabs',
      count: masterHubMetrics.slabs + (slabs.length - 5),
      description: 'Weight slabs, base tariffs and extra rates',
      icon: Layers,
      colorScheme: {
        bgIcon: 'bg-purple-50 text-purple-600 dark:bg-purple-950/50 dark:text-purple-400',
        border: 'border-purple-100 dark:border-purple-900/30',
        accent: 'text-purple-600 dark:text-purple-400',
      },
    },
    {
      id: 'master-routes',
      title: 'Routes',
      count: masterHubMetrics.routes + (routes.length - 6),
      description: 'Origin-destination pairs, transit days & distance',
      icon: Truck,
      colorScheme: {
        bgIcon: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400',
        border: 'border-indigo-100 dark:border-indigo-900/30',
        accent: 'text-indigo-600 dark:text-indigo-400',
      },
    },
    {
      id: 'master-employees',
      title: 'Employees',
      count: masterHubMetrics.employees + (employees.length - 5),
      description: 'Staff directory, branches, designations & roles',
      icon: Briefcase,
      colorScheme: {
        bgIcon: 'bg-cyan-50 text-cyan-600 dark:bg-cyan-950/50 dark:text-cyan-400',
        border: 'border-cyan-100 dark:border-cyan-900/30',
        accent: 'text-cyan-600 dark:text-cyan-400',
      },
    },
    {
      id: 'master-manifest-companies',
      title: 'Manifest Company',
      count: masterHubMetrics.manifestCompanies + (manifestCompanies.length - 4),
      description: 'Carrier partners, air airlines and freight lines',
      icon: Building2,
      colorScheme: {
        bgIcon: 'bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400',
        border: 'border-rose-100 dark:border-rose-900/30',
        accent: 'text-rose-600 dark:text-rose-400',
      },
    },
    {
      id: 'master-stations',
      title: 'Stations',
      count: masterHubMetrics.stations + (stations.length - 5),
      description: 'Mother hubs, transit stations and airport gateways',
      icon: Radio,
      colorScheme: {
        bgIcon: 'bg-sky-50 text-sky-600 dark:bg-sky-950/50 dark:text-sky-400',
        border: 'border-sky-100 dark:border-sky-900/30',
        accent: 'text-sky-600 dark:text-sky-400',
      },
    },
    {
      id: 'master-loaders',
      title: 'Manifest Co Loaders',
      count: masterHubMetrics.loaders + (loaders.length - 3),
      description: 'Co-loaders, cargo handlers and hub associates',
      icon: Boxes,
      colorScheme: {
        bgIcon: 'bg-teal-50 text-teal-600 dark:bg-teal-950/50 dark:text-teal-400',
        border: 'border-teal-100 dark:border-teal-900/30',
        accent: 'text-teal-600 dark:text-teal-400',
      },
    },
    {
      id: 'master-tax',
      title: 'Tax',
      count: masterHubMetrics.tax + (taxEntries.length - 3),
      description: 'GST rate configurations, HSN codes & RCM slabs',
      icon: Receipt,
      colorScheme: {
        bgIcon: 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300',
        border: 'border-blue-100 dark:border-blue-900/30',
        accent: 'text-blue-700 dark:text-blue-300',
      },
    },
    {
      id: 'master-suppliers',
      title: 'Supplier / Courier',
      count: masterHubMetrics.suppliers + (suppliers.length - 3),
      description: 'Third-party delivery vendors and tracking URLs',
      icon: Share2,
      colorScheme: {
        bgIcon: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
        border: 'border-emerald-100 dark:border-emerald-900/30',
        accent: 'text-emerald-700 dark:text-emerald-300',
      },
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Master Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your master data efficiently across 11 core logistics categories.
          </p>
        </div>
      </div>

      {/* Grid of Master Cards (Matches screenshot!) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {masterCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              onClick={() => setActiveNav(card.id)}
              className="group bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-md hover:border-blue-400 dark:hover:border-blue-500/50 transition-all duration-200 cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center border ${card.colorScheme.border} ${card.colorScheme.bgIcon} group-hover:scale-105 transition-transform`}
                  >
                    <Icon className="w-6 h-6 stroke-[1.75]" />
                  </div>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {card.count.toLocaleString()} Records
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-4 group-hover:text-blue-600 dark:group-hover:text-cyan-400 transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {card.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300 group-hover:text-blue-600 dark:group-hover:text-cyan-400">
                <span>Manage Master</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
