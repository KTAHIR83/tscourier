'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { BrandLogo } from '@/components/ui/BrandLogo';
import { ActiveNav } from '@/types';
import {
  LayoutDashboard,
  Database,
  Layers,
  FileText,
  Settings,
  ChevronDown,
  ChevronRight,
  LogOut,
  Sun,
  Moon,
  ChevronLeft,
  X,
  Users,
  MapPin,
  Compass,
  Briefcase,
  Building2,
  Radio,
  Truck,
  Receipt,
  Share2,
  PackagePlus,
  Boxes,
  Activity,
  Search,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    activeNav,
    setActiveNav,
    sidebarCollapsed,
    setSidebarCollapsed,
    mobileSidebarOpen,
    setMobileSidebarOpen,
    theme,
    toggleTheme,
    logout,
  } = useApp();

  const [masterExpanded, setMasterExpanded] = useState<boolean>(true);
  const [transExpanded, setTransExpanded] = useState<boolean>(true);
  const [reportsExpanded, setReportsExpanded] = useState<boolean>(false);

  const handleNavClick = (nav: ActiveNav) => {
    setActiveNav(nav);
    setMobileSidebarOpen(false);
  };

  const isMasterActive = activeNav.startsWith('master-');
  const isTransActive = activeNav.startsWith('transactions-');
  const isReportsActive = activeNav === 'reports';

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-xs lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* Main Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col bg-[#0B132B] text-slate-300 transition-all duration-300 border-r border-[#1E293B]/70 ${
          sidebarCollapsed ? 'w-20' : 'w-72'
        } ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Header / Brand */}
        <div className="flex items-center justify-between h-20 px-5 border-b border-[#1E293B]/80 flex-shrink-0">
          <BrandLogo collapsed={sidebarCollapsed} lightText={true} />

          {/* Close for mobile */}
          <button
            onClick={() => setMobileSidebarOpen(false)}
            className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Collapse toggle for desktop */}
          <button
            onClick={() => setSidebarCollapsed((prev) => !prev)}
            className="hidden lg:flex p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            title={sidebarCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            <ChevronLeft
              className={`w-4 h-4 transition-transform duration-200 ${
                sidebarCollapsed ? 'rotate-180' : ''
              }`}
            />
          </button>
        </div>

        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto py-5 px-3 space-y-1.5 custom-sidebar-scroll">
          {/* Dashboard */}
          <button
            onClick={() => handleNavClick('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs transition-all ${
              activeNav === 'dashboard'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
            title="Dashboard"
          >
            <LayoutDashboard className="w-4 h-4 flex-shrink-0" />
            {!sidebarCollapsed && <span>Dashboard</span>}
          </button>

          {/* MASTER MENU GROUP */}
          <div className="pt-2">
            {!sidebarCollapsed ? (
              <button
                onClick={() => setMasterExpanded(!masterExpanded)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-colors ${
                  isMasterActive
                    ? 'text-cyan-400 bg-white/5'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Database className="w-4 h-4 flex-shrink-0 text-cyan-400" />
                  <span>Master</span>
                </div>
                {masterExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
              </button>
            ) : (
              <button
                onClick={() => handleNavClick('master-overview')}
                className={`w-full flex justify-center p-2.5 rounded-xl transition-colors ${
                  isMasterActive ? 'bg-cyan-500/20 text-cyan-400' : 'text-slate-400 hover:bg-white/5'
                }`}
                title="Master Management"
              >
                <Database className="w-4 h-4" />
              </button>
            )}

            {/* Sub-items */}
            {!sidebarCollapsed && masterExpanded && (
              <div className="pl-4 mt-1 space-y-0.5 border-l border-slate-700/60 ml-5 text-xs">
                <button
                  onClick={() => handleNavClick('master-overview')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-overview'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Master Overview</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-customers')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-customers'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Customers / Outbound</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-cities')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-cities'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Cities</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-areas')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-areas'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Areas</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-slabs')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-slabs'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Slabs</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-routes')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-routes'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Routes</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-employees')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-employees'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>Employees</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-manifest-companies')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-manifest-companies'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Manifest Companies</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-stations')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-stations'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>Stations</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-loaders')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-loaders'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Boxes className="w-3.5 h-3.5" />
                  <span>Manifest Co Loaders</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-tax')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-tax'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Tax Master</span>
                </button>
                <button
                  onClick={() => handleNavClick('master-suppliers')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'master-suppliers'
                      ? 'text-cyan-300 bg-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Supplier / Courier</span>
                </button>
              </div>
            )}
          </div>

          {/* TRANSACTIONS MENU GROUP */}
          <div className="pt-2">
            {!sidebarCollapsed ? (
              <button
                onClick={() => setTransExpanded(!transExpanded)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-colors ${
                  isTransActive
                    ? 'text-blue-400 bg-white/5'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Activity className="w-4 h-4 flex-shrink-0 text-blue-400" />
                  <span>Transactions</span>
                </div>
                {transExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
              </button>
            ) : (
              <button
                onClick={() => handleNavClick('transactions-consignments')}
                className={`w-full flex justify-center p-2.5 rounded-xl transition-colors ${
                  isTransActive ? 'bg-blue-600/30 text-blue-400' : 'text-slate-400 hover:bg-white/5'
                }`}
                title="Transactions"
              >
                <Activity className="w-4 h-4" />
              </button>
            )}

            {!sidebarCollapsed && transExpanded && (
              <div className="pl-4 mt-1 space-y-0.5 border-l border-slate-700/60 ml-5 text-xs">
                <button
                  onClick={() => handleNavClick('transactions-consignments')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'transactions-consignments'
                      ? 'text-blue-300 bg-blue-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Boxes className="w-3.5 h-3.5" />
                  <span>Consignments List</span>
                </button>
                <button
                  onClick={() => handleNavClick('transactions-create-consignment')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'transactions-create-consignment'
                      ? 'text-blue-300 bg-blue-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <PackagePlus className="w-3.5 h-3.5 text-blue-400" />
                  <span>+ Create Consignment</span>
                </button>
                <button
                  onClick={() => handleNavClick('transactions-manifests')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'transactions-manifests'
                      ? 'text-blue-300 bg-blue-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Manifest Operations</span>
                </button>
                <button
                  onClick={() => handleNavClick('transactions-tracking')}
                  className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeNav === 'transactions-tracking'
                      ? 'text-blue-300 bg-blue-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  <Search className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Track Shipment</span>
                </button>
              </div>
            )}
          </div>

          {/* REPORTS */}
          <div className="pt-2">
            <button
              onClick={() => handleNavClick('reports')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs transition-all ${
                activeNav === 'reports'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
              title="Reports Center"
            >
              <FileText className="w-4 h-4 flex-shrink-0" />
              {!sidebarCollapsed && <span>Reports</span>}
            </button>
          </div>

          {/* DATABASE UTILITY */}
          <button
            onClick={() => handleNavClick('database-utility')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs transition-all ${
              activeNav === 'database-utility'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
            title="Database Utility"
          >
            <Database className="w-4 h-4 flex-shrink-0" />
            {!sidebarCollapsed && <span>Database Utility</span>}
          </button>

          {/* SETTINGS */}
          <button
            onClick={() => handleNavClick('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs transition-all ${
              activeNav === 'settings'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
            title="Settings"
          >
            <Settings className="w-4 h-4 flex-shrink-0" />
            {!sidebarCollapsed && <span>Settings</span>}
          </button>
        </div>

        {/* Footer info & Dark Mode & Logout */}
        <div className="p-3 border-t border-[#1E293B] bg-[#070D1F]/50 flex-shrink-0">
          {/* Light / Dark Mode Toggle Button */}
          <div className="flex items-center justify-between px-2 py-1.5 mb-2">
            {!sidebarCollapsed && (
              <span className="text-[11px] font-medium text-slate-400">
                Light / Dark
              </span>
            )}
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title="Toggle theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-300" />
              )}
            </button>
          </div>

          {/* Version badge */}
          {!sidebarCollapsed && (
            <div className="text-[10px] text-slate-500 px-2 pb-2">
              TSIBIS Solution v2.0
            </div>
          )}

          {/* Logout */}
          <button
            onClick={logout}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 transition-colors ${
              sidebarCollapsed ? 'justify-center' : ''
            }`}
            title="Log Out"
          >
            <LogOut className="w-4 h-4 flex-shrink-0" />
            {!sidebarCollapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
};
