'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Menu,
  Search,
  Bell,
  Calendar,
  Clock,
  ChevronDown,
  User,
  LogOut,
  Settings,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

export const Topbar: React.FC = () => {
  const {
    sidebarCollapsed,
    setMobileSidebarOpen,
    setIsGlobalSearchOpen,
    financialYear,
    setFinancialYear,
    currentUser,
    activeNav,
    setActiveNav,
    alerts,
    markAlertAsRead,
    logout,
  } = useApp();

  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('10:24 AM');
  const [currentDate, setCurrentDate] = useState<string>('Mon, 25 Aug 2025');

  useEffect(() => {
    // Keep dynamic or fallback to realistic mockup date/time
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        })
      );
      setCurrentDate(
        now.toLocaleDateString('en-US', {
          weekday: 'short',
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const unreadAlerts = alerts.filter((a) => !a.read);

  // Generate breadcrumb and title based on activeNav
  const getNavMeta = () => {
    switch (activeNav) {
      case 'dashboard':
        return { title: 'Dashboard', breadcrumbs: ['Overview'] };
      case 'master-overview':
        return { title: 'Master Management', breadcrumbs: ['Master', 'Overview'] };
      case 'master-customers':
        return { title: 'Customer / Outbound Party Master', breadcrumbs: ['Master', 'Customers'] };
      case 'master-cities':
        return { title: 'City Master Entry', breadcrumbs: ['Master', 'Cities'] };
      case 'master-areas':
        return { title: 'Area Master Entry', breadcrumbs: ['Master', 'Areas'] };
      case 'master-slabs':
        return { title: 'Slab Master Rates', breadcrumbs: ['Master', 'Slabs'] };
      case 'master-routes':
        return { title: 'Route Master Operations', breadcrumbs: ['Master', 'Routes'] };
      case 'master-employees':
        return { title: 'Employee Master', breadcrumbs: ['Master', 'Employees'] };
      case 'master-manifest-companies':
        return { title: 'Manifest Company Master', breadcrumbs: ['Master', 'Manifest Companies'] };
      case 'master-stations':
        return { title: 'Station Master', breadcrumbs: ['Master', 'Stations'] };
      case 'master-loaders':
        return { title: 'Manifest Co Loaders', breadcrumbs: ['Master', 'Loaders'] };
      case 'master-tax':
        return { title: 'Tax Entry Master (GST)', breadcrumbs: ['Master', 'Tax'] };
      case 'master-suppliers':
        return { title: 'Supplier Courier Master', breadcrumbs: ['Master', 'Suppliers'] };
      case 'transactions-consignments':
        return { title: 'Consignment Operations', breadcrumbs: ['Transactions', 'Consignments'] };
      case 'transactions-create-consignment':
        return { title: 'Transaction — Create Consignment', breadcrumbs: ['Transactions', 'Consignment', 'Create'] };
      case 'transactions-manifests':
        return { title: 'Manifest Operations', breadcrumbs: ['Transactions', 'Manifests'] };
      case 'transactions-tracking':
        return { title: 'Live Shipment Tracking', breadcrumbs: ['Transactions', 'Tracking'] };
      case 'reports':
        return { title: 'Reports & Analytics Center', breadcrumbs: ['Reports', 'Overview'] };
      case 'database-utility':
        return { title: 'Database Utility & Maintenance', breadcrumbs: ['Utilities', 'Database'] };
      case 'settings':
        return { title: 'System & Company Settings', breadcrumbs: ['Settings', 'General'] };
      default:
        return { title: 'TSIBIS Solution', breadcrumbs: ['Home'] };
    }
  };

  const navMeta = getNavMeta();

  return (
    <header
      className={`sticky top-0 z-30 flex items-center justify-between h-20 px-4 sm:px-6 lg:px-8 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-all duration-300 ${
        sidebarCollapsed ? 'lg:pl-24' : 'lg:pl-76'
      }`}
    >
      {/* LEFT: Toggle, Breadcrumbs & Title */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileSidebarOpen(true)}
          className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          {/* Breadcrumb pills */}
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500 font-medium">
            <span>TSIBIS</span>
            {navMeta.breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={idx}>
                <span className="text-slate-300 dark:text-slate-600">/</span>
                <span className={idx === navMeta.breadcrumbs.length - 1 ? 'text-blue-600 dark:text-cyan-400 font-semibold' : ''}>
                  {crumb}
                </span>
              </React.Fragment>
            ))}
          </div>
          <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-tight">
            {navMeta.title}
          </h1>
        </div>
      </div>

      {/* CENTER: Global Search Bar */}
      <div className="hidden md:flex flex-1 max-w-md mx-6">
        <button
          onClick={() => setIsGlobalSearchOpen(true)}
          className="w-full flex items-center justify-between px-3.5 py-2 text-xs text-slate-400 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl border border-slate-200/70 dark:border-slate-700/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Search className="w-4 h-4 text-slate-400" />
            <span>Search consignment, customer, city...</span>
          </div>
          <kbd className="hidden sm:inline-flex items-center px-1.5 py-0.5 font-mono text-[10px] text-slate-500 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
            Ctrl+K
          </kbd>
        </button>
      </div>

      {/* RIGHT: Financial Year, Date/Time, Notifications, Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Date & Time pill (matches mockup!) */}
        <div className="hidden xl:flex items-center gap-3 px-3 py-1.5 bg-slate-100/70 dark:bg-slate-800/70 rounded-xl border border-slate-200/60 dark:border-slate-700/50 text-xs text-slate-600 dark:text-slate-300">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400" />
            <span className="font-medium">{currentDate}</span>
          </div>
          <span className="text-slate-300 dark:text-slate-600">|</span>
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400" />
            <span className="font-medium font-mono">{currentTime}</span>
          </div>
        </div>

        {/* Financial Year Selector */}
        <div className="flex items-center gap-1 bg-slate-100/80 dark:bg-slate-800/80 px-2.5 py-1.5 rounded-xl border border-slate-200/70 dark:border-slate-700/60 text-xs">
          <span className="text-[11px] font-medium text-slate-400 hidden sm:inline">FY:</span>
          <select
            value={financialYear}
            onChange={(e) => setFinancialYear(e.target.value)}
            className="bg-transparent font-semibold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-1"
          >
            <option value="2025-26" className="dark:bg-slate-800">2025 - 26</option>
            <option value="2024-25" className="dark:bg-slate-800">2024 - 25</option>
            <option value="2023-24" className="dark:bg-slate-800">2023 - 24</option>
          </select>
        </div>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="relative p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            title="System Alerts"
          >
            <Bell className="w-5 h-5" />
            {unreadAlerts.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </button>

          {/* Notifications Dropdown */}
          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-4 z-40 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">System Alerts</h4>
                  {unreadAlerts.length > 0 && (
                    <span className="px-2 py-0.5 text-[10px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 rounded-full">
                      {unreadAlerts.length} new
                    </span>
                  )}
                </div>
                <button
                  onClick={() => alerts.forEach((a) => markAlertAsRead(a.id))}
                  className="text-[11px] text-blue-600 dark:text-cyan-400 hover:underline"
                >
                  Mark all read
                </button>
              </div>

              <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    onClick={() => {
                      markAlertAsRead(alert.id);
                      if (alert.link) setActiveNav(alert.link as any);
                      setNotificationsOpen(false);
                    }}
                    className={`p-2.5 rounded-xl cursor-pointer transition-colors text-xs ${
                      alert.read
                        ? 'bg-slate-50/60 dark:bg-slate-800/40 text-slate-500'
                        : 'bg-blue-50/60 dark:bg-blue-950/30 text-slate-800 dark:text-slate-200 border border-blue-100 dark:border-blue-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-slate-900 dark:text-white">{alert.title}</span>
                      <span className="text-[10px] text-slate-400 font-normal">{alert.timestamp}</span>
                    </div>
                    <p className="mt-1 text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
                      {alert.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile */}
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-xs shadow-sm">
              {currentUser.name.charAt(0)}
            </div>
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-none">
                {currentUser.name}
              </span>
              <span className="text-[10px] text-slate-400 leading-tight mt-0.5">
                {currentUser.role}
              </span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
          </button>

          {/* Profile Dropdown */}
          {profileOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-2 z-40 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                <p className="text-xs font-bold text-slate-900 dark:text-white">{currentUser.name}</p>
                <p className="text-[11px] text-slate-400 truncate">{currentUser.email}</p>
                <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-medium">
                  {currentUser.branch}
                </span>
              </div>

              <div className="py-1 text-xs">
                <button
                  onClick={() => {
                    setActiveNav('settings');
                    setProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <Settings className="w-4 h-4 text-slate-400" />
                  <span>Company Settings</span>
                </button>
                <button
                  onClick={() => {
                    setActiveNav('database-utility');
                    setProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ShieldCheck className="w-4 h-4 text-slate-400" />
                  <span>Database Health</span>
                </button>
              </div>

              <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
