'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Sidebar } from '@/components/layout/Sidebar';
import { Topbar } from '@/components/layout/Topbar';
import { LoginView } from '@/components/auth/LoginView';
import { DashboardView } from '@/components/dashboard/DashboardView';
import { MasterOverviewView } from '@/components/master/MasterOverviewView';
import { CityMasterView } from '@/components/master/CityMasterView';
import { CustomerMasterView } from '@/components/master/CustomerMasterView';
import { GenericMasterView } from '@/components/master/GenericMasterView';
import { CreateConsignmentView } from '@/components/transactions/CreateConsignmentView';
import { ConsignmentListView } from '@/components/transactions/ConsignmentListView';
import { ManifestView } from '@/components/transactions/ManifestView';
import { TrackingView } from '@/components/transactions/TrackingView';
import { ReportsView } from '@/components/reports/ReportsView';
import { DatabaseUtilityView } from '@/components/utility/DatabaseUtilityView';
import { SettingsView } from '@/components/settings/SettingsView';
import { GlobalSearchModal } from '@/components/ui/GlobalSearchModal';
import { ToastContainer } from '@/components/ui/ToastContainer';

export const AppShell: React.FC = () => {
  const { isAuthenticated, activeNav, sidebarCollapsed } = useApp();

  if (!isAuthenticated) {
    return (
      <>
        <LoginView />
        <ToastContainer />
      </>
    );
  }

  const renderActiveModule = () => {
    switch (activeNav) {
      case 'dashboard':
        return <DashboardView />;
      case 'master-overview':
        return <MasterOverviewView />;
      case 'master-customers':
        return <CustomerMasterView />;
      case 'master-cities':
        return <CityMasterView />;
      case 'master-areas':
        return <GenericMasterView type="areas" />;
      case 'master-slabs':
        return <GenericMasterView type="slabs" />;
      case 'master-routes':
        return <GenericMasterView type="routes" />;
      case 'master-employees':
        return <GenericMasterView type="employees" />;
      case 'master-manifest-companies':
        return <GenericMasterView type="manifest-companies" />;
      case 'master-stations':
        return <GenericMasterView type="stations" />;
      case 'master-loaders':
        return <GenericMasterView type="loaders" />;
      case 'master-tax':
        return <GenericMasterView type="tax" />;
      case 'master-suppliers':
        return <GenericMasterView type="suppliers" />;
      case 'transactions-consignments':
        return <ConsignmentListView />;
      case 'transactions-create-consignment':
        return <CreateConsignmentView />;
      case 'transactions-manifests':
        return <ManifestView />;
      case 'transactions-tracking':
        return <TrackingView />;
      case 'reports':
        return <ReportsView />;
      case 'database-utility':
        return <DatabaseUtilityView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0B1120] text-slate-900 dark:text-slate-100 flex flex-col antialiased">
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Top Bar */}
      <Topbar />

      {/* Main Content Viewport */}
      <main
        className={`flex-1 p-4 sm:p-6 lg:p-8 transition-all duration-300 ${
          sidebarCollapsed ? 'lg:pl-24' : 'lg:pl-76'
        }`}
      >
        <div className="max-w-7xl mx-auto">
          {renderActiveModule()}
        </div>
      </main>

      {/* Global Utilities & Modals */}
      <GlobalSearchModal />
      <ToastContainer />
    </div>
  );
};
