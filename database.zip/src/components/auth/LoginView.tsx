'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { BrandLogo } from '@/components/ui/BrandLogo';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  Calendar,
  ShieldCheck,
  Radio,
  Zap,
  ArrowRight,
  Truck,
  CheckCircle2,
  Sparkles,
  Layers,
  Globe2,
  Building2,
  Fingerprint,
  ChevronRight,
  Star,
  Activity,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, financialYear } = useApp();

  // Form states
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loginYear, setLoginYear] = useState(financialYear || '2025-26');
  const [selectedRole, setSelectedRole] = useState<'admin' | 'branch' | 'employee'>('employee');
  const [selectedBranch, setSelectedBranch] = useState('Head Office — Mumbai');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeVisual, setActiveVisual] = useState<number>(1);

  // Role select helper
  const handleRoleSelect = (role: 'admin' | 'branch' | 'employee') => {
    setSelectedRole(role);
    if (role === 'admin') {
      setUsername('admin');
      setPassword('admin123');
    } else if (role === 'branch') {
      setUsername('branch.mumbai');
      setPassword('mumbai2025');
    } else {
      setUsername('EMP-4089');
      setPassword('emp9900');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      login(username, password, loginYear);
      setIsSubmitting(false);
    }, 450);
  };

  const handleInstantDemo = () => {
    login('admin', 'admin123', '2025-26');
  };

  return (
    <div className="min-h-screen w-full flex bg-[#070B19] text-slate-100 font-sans selection:bg-cyan-500 selection:text-white relative overflow-hidden">
      {/* AMBIENT AURORA & GLOW EFFECTS */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-gradient-to-br from-blue-600/25 via-indigo-600/20 to-transparent rounded-full blur-[140px]" />
        <div className="absolute top-1/3 -right-40 w-[550px] h-[550px] bg-gradient-to-bl from-cyan-500/20 via-sky-600/15 to-transparent rounded-full blur-[140px]" />
        <div className="absolute -bottom-40 left-1/4 w-[650px] h-[650px] bg-gradient-to-tr from-indigo-700/20 via-purple-600/10 to-transparent rounded-full blur-[160px]" />
        {/* Subtle dot matrix grid */}
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, #FFFFFF 1px, transparent 0)',
            backgroundSize: '24px 24px',
          }}
        />
      </div>

      {/* LEFT PANEL: Live Logistics Telemetry & Visual Showcase */}
      <div className="relative flex-1 hidden lg:flex flex-col justify-between p-12 xl:p-16 z-10 border-r border-white/[0.08] backdrop-blur-xs">
        {/* Top bar with brand & live ping */}
        <div className="flex items-center justify-between">
          <BrandLogo lightText={true} />
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.06] border border-white/[0.1] text-xs backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-emerald-300 font-semibold text-[11px]">
              74/74 HUBS ONLINE • 24ms
            </span>
          </div>
        </div>

        {/* Central interactive hero presentation */}
        <div className="my-auto py-8 max-w-xl">
          {/* Tagline badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-cyan-500/15 via-blue-500/15 to-indigo-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-6 shadow-sm shadow-cyan-500/10">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span>Next-Gen Intelligent Freight Platform</span>
          </div>

          <h1 className="text-4xl xl:text-5xl font-black tracking-tight text-white leading-[1.15]">
            Powering Nationwide Logistics with{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 bg-clip-text text-transparent">
              Precision & Speed
            </span>
          </h1>

          <p className="mt-4 text-slate-300 text-sm xl:text-base leading-relaxed">
            Consolidate airway bills, automate multi-modal line-haul manifests, and monitor shipment SLAs across India on a single unified console.
          </p>

          {/* REAL-TIME TELEMETRY CARD (Trending Glassmorphism widget) */}
          <div className="mt-8 rounded-2xl bg-white/[0.04] border border-white/[0.1] p-5 backdrop-blur-xl shadow-2xl relative overflow-hidden group hover:border-cyan-500/40 transition-all duration-300">
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

            {/* Flight / Line-Haul Route Strip */}
            <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">Line-Haul Express #LH-904</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                      IN TRANSIT
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">Delhi Mother Hub (DEL) → Mumbai Gateway (BOM)</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-black font-mono text-cyan-400">99.2%</span>
                <span className="block text-[10px] text-slate-400">On-Time SLA</span>
              </div>
            </div>

            {/* Progress line */}
            <div className="py-3">
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-1.5">
                <span>Departed 08:30 AM</span>
                <span className="text-cyan-400 font-semibold">ETA: 02:45 PM Today</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/[0.06] overflow-hidden p-0.5">
                <div className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 rounded-full w-3/4 animate-pulse" />
              </div>
            </div>

            {/* Micro stats counter */}
            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-white/[0.08] text-center">
              <div className="p-2 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                <span className="text-[10px] text-slate-400 block uppercase font-medium">Today Vol</span>
                <span className="text-sm font-black text-white font-mono">12,842 AWB</span>
              </div>
              <div className="p-2 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                <span className="text-[10px] text-slate-400 block uppercase font-medium">Active Fleet</span>
                <span className="text-sm font-black text-cyan-400 font-mono">1,420 Trucks</span>
              </div>
              <div className="p-2 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                <span className="text-[10px] text-slate-400 block uppercase font-medium">Freight Value</span>
                <span className="text-sm font-black text-emerald-400 font-mono">₹4.8 Cr</span>
              </div>
            </div>
          </div>

          {/* Social Proof Testimonial Card */}
          <div className="mt-6 flex items-start gap-3.5 p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.06]">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-[10px] font-bold text-white ring-2 ring-[#070B19]">
                RS
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-amber-400 mb-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-amber-400" />
                ))}
              </div>
              <p className="text-xs text-slate-300 italic">
                &ldquo;TSIBIS transformed our regional cargo operations. Booking consignments and tracking manifests is 4x faster.&rdquo;
              </p>
              <p className="text-[10px] text-slate-500 mt-1 font-medium">
                — Head of Freight Operations, Index Express Logistics
              </p>
            </div>
          </div>
        </div>

        {/* Footer badges */}
        <div className="pt-6 border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>AES-256 Cloud Vault</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-blue-400" />
            <span>Pan-India Transit Network</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>99.99% Guaranteed SLA</span>
          </div>
        </div>
      </div>

      {/* RIGHT PANEL: Modern Trending Glassmorphic Sign-In Card */}
      <div className="flex-1 flex flex-col justify-center items-center p-6 sm:p-10 lg:p-14 z-10">
        <div className="w-full max-w-[440px]">
          {/* Card Container with subtle border glow */}
          <div className="relative bg-[#0D1428]/80 backdrop-blur-2xl rounded-3xl p-8 sm:p-9 border border-white/[0.1] shadow-2xl shadow-black/80">
            {/* Top glowing ambient highlight */}
            <div className="absolute -top-[1px] left-1/4 right-1/4 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />

            {/* Mobile Brand Logo */}
            <div className="lg:hidden mb-6 flex justify-center">
              <BrandLogo lightText={true} />
            </div>

            {/* Header */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2.5 py-0.5 rounded-full">
                  Enterprise Access
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {loginYear}
                </span>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight mt-2.5">
                Sign In to Console
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Enter your credentials or choose a quick role below
              </p>
            </div>

            {/* QUICK ROLE SELECTOR CHIPS (Trending feature) */}
            <div className="mb-5">
              <label className="block text-[11px] font-semibold text-slate-400 mb-2">
                Quick Role Switcher:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'admin', label: 'Admin', badge: 'Superuser' },
                  { id: 'operations', label: 'Operations', badge: 'Hub Lead' },
                  { id: 'dispatch', label: 'Dispatch', badge: 'Fleet' },
                ].map((role) => (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => handleRoleSelect(role.id as any)}
                    className={`py-2 px-2.5 rounded-xl text-left border transition-all ${
                      selectedRole === role.id
                        ? 'bg-gradient-to-b from-blue-600/30 to-cyan-600/20 border-cyan-500/60 text-white shadow-sm shadow-cyan-500/20'
                        : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    <span className="block text-xs font-bold leading-none">{role.label}</span>
                    <span className="block text-[9px] text-slate-400 mt-1">{role.badge}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* ENTERPRISE SSO PROVIDERS */}
            <div className="space-y-2 mb-5">
              <button
                type="button"
                onClick={handleInstantDemo}
                className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-200 bg-white/[0.05] hover:bg-white/[0.09] border border-white/[0.1] transition-all"
              >
                {/* Google Icon */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.4l3.7 2.9C6.5 7.4 9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.8z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.6 14.7c-.2-.7-.4-1.5-.4-2.7s.1-2 .4-2.7L1.9 6.4C.7 8.8 0 10.3 0 12s.7 3.2 1.9 5.6l3.7-2.9z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2-6.4-4.8L1.9 16.4C3.7 20.3 7.5 23 12 23z"
                  />
                </svg>
                <span>Continue with Google Workspace</span>
              </button>

              <button
                type="button"
                onClick={handleInstantDemo}
                className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-200 bg-white/[0.05] hover:bg-white/[0.09] border border-white/[0.1] transition-all"
              >
                {/* Microsoft Icon */}
                <svg className="w-4 h-4" viewBox="0 0 23 23">
                  <path fill="#F35325" d="M1 1h10v10H1z" />
                  <path fill="#81BC06" d="M12 1h10v10H12z" />
                  <path fill="#05A6F0" d="M1 12h10v10H1z" />
                  <path fill="#FFBA08" d="M12 12h10v10H12z" />
                </svg>
                <span>Sign in with Microsoft 365</span>
              </button>
            </div>

            {/* Divider */}
            <div className="relative flex items-center justify-center my-5">
              <div className="w-full border-t border-white/[0.08]" />
              <span className="absolute bg-[#0D1428] px-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                or with credentials
              </span>
            </div>

            {/* FORM */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Username Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Account ID or Username
                </label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 group-focus-within:text-cyan-400 transition-colors">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. admin or ops.lead"
                    className="w-full pl-10 pr-4 py-2.5 bg-white/[0.04] border border-white/[0.1] rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/40 focus:border-cyan-500 transition-all font-medium"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Security Password
                  </label>
                  <button
                    type="button"
                    onClick={() => alert('Password recovery dispatch sent to registered email.')}
                    className="text-[11px] font-medium text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    Forgot?
                  </button>
                </div>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 group-focus-within:text-cyan-400 transition-colors">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full pl-10 pr-10 py-2.5 bg-white/[0.04] border border-white/[0.1] rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/40 focus:border-cyan-500 transition-all font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Financial Year Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Financial Year / Session
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <select
                    value={loginYear}
                    onChange={(e) => {
                      setLoginYear(e.target.value);
                      setFinancialYear(e.target.value);
                    }}
                    className="w-full pl-10 pr-8 py-2.5 bg-white/[0.04] border border-white/[0.1] rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/40 focus:border-cyan-500 appearance-none cursor-pointer transition-all"
                  >
                    <option value="2025-26" className="bg-[#0D1428] text-white">
                      2025 - 2026 (Active Operating FY)
                    </option>
                    <option value="2024-25" className="bg-[#0D1428] text-white">
                      2024 - 2025 (Audit Archive)
                    </option>
                    <option value="2023-24" className="bg-[#0D1428] text-white">
                      2023 - 2024 (Historical Data)
                    </option>
                  </select>
                </div>
              </div>

              {/* Remember me & Passkey */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-500/30 border-white/[0.2] bg-white/[0.05]"
                  />
                  <span className="text-xs text-slate-400">Remember session for 30 days</span>
                </label>
              </div>

              {/* Trending Gradient Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:via-indigo-500 hover:to-cyan-500 active:scale-[0.99] shadow-lg shadow-cyan-500/25 transition-all duration-200 group"
              >
                <span>{isSubmitting ? 'Authenticating...' : 'Sign In to Console'}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>

            {/* Instant Demo Helper Pill */}
            <div className="mt-4 pt-4 border-t border-white/[0.08] text-center">
              <button
                type="button"
                onClick={handleInstantDemo}
                className="inline-flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>One-Click Instant Demo Access (Admin)</span>
              </button>
            </div>
          </div>

          {/* Bottom Security Trust Bar */}
          <div className="mt-6 flex items-center justify-center gap-4 text-[11px] text-slate-500">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              SOC2 Type II
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Fingerprint className="w-3.5 h-3.5 text-slate-400" />
              256-bit SSL
            </span>
            <span>•</span>
            <span>TSIBIS SOLUTION v2.4</span>
          </div>
        </div>
      </div>
    </div>
  );
};
