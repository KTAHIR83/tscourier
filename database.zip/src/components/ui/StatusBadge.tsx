import React from 'react';
import { ShipmentStatus } from '@/types';

interface StatusBadgeProps {
  status: ShipmentStatus | 'Active' | 'Inactive' | 'Draft' | 'Dispatched' | 'Received at Hub' | 'Closed';
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  let badgeStyle = 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
  let dotColor = 'bg-slate-400';

  switch (status) {
    case 'Delivered':
    case 'Active':
    case 'Closed':
      badgeStyle = 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/50';
      dotColor = 'bg-emerald-500';
      break;

    case 'In Transit':
    case 'Dispatched':
      badgeStyle = 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800/50';
      dotColor = 'bg-blue-500';
      break;

    case 'Pending':
      badgeStyle = 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/50';
      dotColor = 'bg-amber-500';
      break;

    case 'Out for Delivery':
      badgeStyle = 'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-400 dark:border-cyan-800/50';
      dotColor = 'bg-cyan-500 animate-pulse';
      break;

    case 'Arrived at Hub':
    case 'Received at Hub':
      badgeStyle = 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-400 dark:border-purple-800/50';
      dotColor = 'bg-purple-500';
      break;

    case 'Booked':
    case 'Picked Up':
    case 'Draft':
      badgeStyle = 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-400 dark:border-indigo-800/50';
      dotColor = 'bg-indigo-500';
      break;

    case 'Cancelled':
    case 'Inactive':
      badgeStyle = 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800/50';
      dotColor = 'bg-rose-500';
      break;
  }

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border ${sizeClasses} ${badgeStyle} transition-colors`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
      {status}
    </span>
  );
};
