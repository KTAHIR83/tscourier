import React from 'react';

interface BrandLogoProps {
  collapsed?: boolean;
  className?: string;
  lightText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  collapsed = false,
  className = '',
  lightText = true,
}) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Modern geometric T-wing logo mark */}
      <div className="relative flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-700 flex items-center justify-center shadow-lg shadow-blue-500/20 ring-1 ring-white/20">
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-6 h-6 text-white"
        >
          {/* Top horizontal dynamic bar */}
          <path
            d="M5 8.5C5 7.67 5.67 7 6.5 7H25.5C26.33 7 27 7.67 27 8.5C27 9.33 26.33 10 25.5 10H6.5C5.67 10 5 9.33 5 8.5Z"
            fill="currentColor"
          />
          {/* Express speed-wing slant */}
          <path
            d="M9 13C9 12.45 9.45 12 10 12H22C22.55 12 23 12.45 23 13C23 13.55 22.55 14 22 14H10C9.45 14 9 13.55 9 13Z"
            fill="#38BDF8"
          />
          {/* Central stem with arrow accent */}
          <path
            d="M13.5 16.5C13.5 15.67 14.17 15 15 15H17C17.83 15 18.5 15.67 18.5 16.5V23.5L16 26L13.5 23.5V16.5Z"
            fill="currentColor"
          />
        </svg>
      </div>

      {!collapsed && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span
              className={`text-lg font-black tracking-wider leading-none ${
                lightText ? 'text-white' : 'text-slate-900 dark:text-white'
              }`}
            >
              TSIBIS
            </span>
            <span className="text-xs font-semibold uppercase tracking-widest text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20">
              SOLUTION
            </span>
          </div>
          <span
            className={`text-[10px] tracking-wide font-medium mt-1 ${
              lightText ? 'text-slate-400' : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            Fast • Safe • Reliable
          </span>
        </div>
      )}
    </div>
  );
};
