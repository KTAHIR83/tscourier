import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  comparisonPeriod?: string;
  colorTheme?: 'blue' | 'emerald' | 'purple' | 'amber';
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon: Icon,
  change,
  changeType = 'positive',
  comparisonPeriod = 'vs last 30 days',
  colorTheme = 'blue',
}) => {
  const themeStyles = {
    blue: {
      bgIcon: 'bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400 border-blue-100 dark:border-blue-900/40',
      pill: 'bg-blue-50/50 dark:bg-blue-950/20',
    },
    emerald: {
      bgIcon: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/40',
      pill: 'bg-emerald-50/50 dark:bg-emerald-950/20',
    },
    purple: {
      bgIcon: 'bg-purple-50 text-purple-600 dark:bg-purple-950/50 dark:text-purple-400 border-purple-100 dark:border-purple-900/40',
      pill: 'bg-purple-50/50 dark:bg-purple-950/20',
    },
    amber: {
      bgIcon: 'bg-amber-50 text-amber-600 dark:bg-amber-950/50 dark:text-amber-400 border-amber-100 dark:border-amber-900/40',
      pill: 'bg-amber-50/50 dark:bg-amber-950/20',
    },
  }[colorTheme];

  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-200">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 tracking-wide uppercase">
            {title}
          </p>
          <h3 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-1.5">
            {typeof value === 'number' ? value.toLocaleString() : value}
          </h3>
        </div>

        <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${themeStyles.bgIcon} shadow-sm`}>
          <Icon className="w-6 h-6 stroke-[1.75]" />
        </div>
      </div>

      {change && (
        <div className="mt-4 flex items-center gap-2 text-xs">
          <span
            className={`font-semibold flex items-center gap-0.5 ${
              changeType === 'positive'
                ? 'text-emerald-600 dark:text-emerald-400'
                : changeType === 'negative'
                ? 'text-rose-600 dark:text-rose-400'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            {change.startsWith('+') || change.startsWith('-') ? '' : changeType === 'positive' ? '↑ ' : '↓ '}
            {change}
          </span>
          <span className="text-slate-400 dark:text-slate-500">{comparisonPeriod}</span>
        </div>
      )}
    </div>
  );
};
