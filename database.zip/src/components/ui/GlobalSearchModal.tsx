'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { Search, X, Package, Users, MapPin, ArrowRight, CornerDownLeft, Layers } from 'lucide-react';
import { ActiveNav } from '@/types';

export const GlobalSearchModal: React.FC = () => {
  const {
    isGlobalSearchOpen,
    setIsGlobalSearchOpen,
    consignments,
    customers,
    cities,
    setActiveNav,
    setQuickTrackAwb,
  } = useApp();

  const [query, setQuery] = useState('');

  // Handle Ctrl+K shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsGlobalSearchOpen(true);
      }
      if (e.key === 'Escape' && isGlobalSearchOpen) {
        setIsGlobalSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isGlobalSearchOpen, setIsGlobalSearchOpen]);

  if (!isGlobalSearchOpen) return null;

  const trimmed = query.trim().toLowerCase();

  const matchingConsignments = trimmed
    ? consignments.filter(
        (c) =>
          c.awbNumber.toLowerCase().includes(trimmed) ||
          c.customerName.toLowerCase().includes(trimmed) ||
          c.toCity.toLowerCase().includes(trimmed)
      ).slice(0, 4)
    : [];

  const matchingCustomers = trimmed
    ? customers.filter(
        (c) =>
          c.name.toLowerCase().includes(trimmed) ||
          c.code.toLowerCase().includes(trimmed) ||
          c.city.toLowerCase().includes(trimmed)
      ).slice(0, 4)
    : [];

  const matchingCities = trimmed
    ? cities.filter(
        (c) =>
          c.cityName.toLowerCase().includes(trimmed) ||
          c.state.toLowerCase().includes(trimmed) ||
          c.pinCode.includes(trimmed)
      ).slice(0, 4)
    : [];

  const quickNavItems: { label: string; nav: ActiveNav; icon: any }[] = [
    { label: 'Dashboard & KPIs', nav: 'dashboard', icon: Layers },
    { label: 'Create New Consignment', nav: 'transactions-create-consignment', icon: Package },
    { label: 'Track Shipment', nav: 'transactions-tracking', icon: Package },
    { label: 'Master Management Hub', nav: 'master-overview', icon: Users },
    { label: 'Reports & Analytics Center', nav: 'reports', icon: Layers },
    { label: 'Database Maintenance Utility', nav: 'database-utility', icon: Layers },
  ];

  const handleSelectNav = (nav: ActiveNav) => {
    setActiveNav(nav);
    setIsGlobalSearchOpen(false);
    setQuery('');
  };

  const handleSelectConsignment = (awb: string) => {
    setQuickTrackAwb(awb);
    setActiveNav('transactions-tracking');
    setIsGlobalSearchOpen(false);
    setQuery('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4">
      <div
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsGlobalSearchOpen(false)}
      />

      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 dark:border-slate-800">
          <Search className="w-5 h-5 text-slate-400 mr-3" />
          <input
            type="text"
            placeholder="Search consignments, customers, cities, routes, or jump to module..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-800 text-slate-500 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
            ESC
          </span>
        </div>

        {/* Results area */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4 text-xs">
          {trimmed ? (
            <>
              {/* Consignments */}
              {matchingConsignments.length > 0 && (
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-2 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-blue-500" />
                    Consignments & AWBs
                  </div>
                  <div className="space-y-1">
                    {matchingConsignments.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => handleSelectConsignment(c.awbNumber)}
                        className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-blue-50 dark:hover:bg-slate-800/60 text-left transition-colors group"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono font-bold text-blue-600 dark:text-blue-400 group-hover:underline">
                            {c.awbNumber}
                          </span>
                          <span className="text-slate-600 dark:text-slate-300">
                            • {c.customerName}
                          </span>
                          <span className="text-slate-400">
                            ({c.fromCity} → {c.toCity})
                          </span>
                        </div>
                        <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {c.status}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Customers */}
              {matchingCustomers.length > 0 && (
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-2 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-cyan-500" />
                    Customers / Outbound Parties
                  </div>
                  <div className="space-y-1">
                    {matchingCustomers.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => handleSelectNav('master-customers')}
                        className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-cyan-50/50 dark:hover:bg-slate-800/60 text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900 dark:text-white">
                            {c.name}
                          </span>
                          <span className="text-slate-400">({c.code})</span>
                        </div>
                        <span className="text-slate-500">{c.city}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Cities */}
              {matchingCities.length > 0 && (
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-2 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                    Cities Master
                  </div>
                  <div className="space-y-1">
                    {matchingCities.map((ct) => (
                      <button
                        key={ct.id}
                        onClick={() => handleSelectNav('master-cities')}
                        className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-emerald-50/50 dark:hover:bg-slate-800/60 text-left transition-colors"
                      >
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {ct.cityName}
                        </span>
                        <span className="text-slate-500">{ct.state} • PIN: {ct.pinCode}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {matchingConsignments.length === 0 && matchingCustomers.length === 0 && matchingCities.length === 0 && (
                <div className="py-8 text-center text-slate-400">
                  <p>No matching records found for &quot;{query}&quot;</p>
                  <p className="text-[11px] text-slate-500 mt-1">Try searching by AWB number, city, or customer name.</p>
                </div>
              )}
            </>
          ) : (
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-2">
                Quick Navigation
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {quickNavItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.nav}
                      onClick={() => handleSelectNav(item.nav)}
                      className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors group"
                    >
                      <div className="flex items-center gap-2.5 text-slate-700 dark:text-slate-200">
                        <Icon className="w-4 h-4 text-blue-500 group-hover:scale-110 transition-transform" />
                        <span className="font-medium">{item.label}</span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span>Press</span>
            <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-[10px] text-slate-600 dark:text-slate-300">
              <CornerDownLeft className="w-3 h-3 inline mr-1" />
              Enter
            </kbd>
            <span>to select</span>
          </div>
          <span>TSIBIS SOLUTION Global Search</span>
        </div>
      </div>
    </div>
  );
};
