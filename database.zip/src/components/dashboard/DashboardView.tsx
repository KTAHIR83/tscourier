'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { StatCard } from '@/components/ui/StatCard';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { sampleActivityChartData } from '@/data/mockData';
import {
  Boxes,
  Truck,
  CheckCircle2,
  Clock,
  PlusCircle,
  FilePlus,
  Search,
  UserPlus,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

export const DashboardView: React.FC = () => {
  const {
    currentUser,
    consignments,
    alerts,
    setActiveNav,
    setQuickTrackAwb,
  } = useApp();

  const [chartTimeRange, setChartTimeRange] = useState<'7d' | '30d' | '90d'>('7d');

  const chartData = sampleActivityChartData[chartTimeRange];

  // Quick navigation helpers
  const handleAwbClick = (awb: string) => {
    setQuickTrackAwb(awb);
    setActiveNav('transactions-tracking');
  };

  return (
    <div className="space-y-6">
      {/* GREETING & HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Dashboard
          </h2>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mt-1">
            Good morning, {currentUser.name}! 👋
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Here&apos;s what&apos;s happening with your logistics business today.
          </p>
        </div>

        {/* Quick action button */}
        <button
          onClick={() => setActiveNav('transactions-create-consignment')}
          className="self-start sm:self-auto flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-xs text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-colors"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Booking</span>
        </button>
      </div>

      {/* TOP 4 KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Consignments"
          value={12842}
          icon={Boxes}
          change="+12%"
          changeType="positive"
          colorTheme="blue"
        />
        <StatCard
          title="In Transit"
          value={1284}
          icon={Truck}
          change="+8%"
          changeType="positive"
          colorTheme="emerald"
        />
        <StatCard
          title="Delivered"
          value={10876}
          icon={CheckCircle2}
          change="+15%"
          changeType="positive"
          colorTheme="purple"
        />
        <StatCard
          title="Pending"
          value={428}
          icon={Clock}
          change="-4%"
          changeType="negative"
          colorTheme="amber"
        />
      </div>

      {/* CHARTS & RECENT CONSIGNMENTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Consignment Activity Line Chart */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-600 dark:text-cyan-400" />
                Consignment Activity
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Volume metrics categorized by delivery status
              </p>
            </div>

            {/* Time range tabs */}
            <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-medium">
              {(['7d', '30d', '90d'] as const).map((range) => (
                <button
                  key={range}
                  onClick={() => setChartTimeRange(range)}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    chartTimeRange === range
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-cyan-300 shadow-xs font-semibold'
                      : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
                </button>
              ))}
            </div>
          </div>

          {/* Chart container */}
          <div className="h-64 sm:h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" opacity={0.4} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(val) => (val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val)}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderRadius: '12px',
                    border: '1px solid #334155',
                    color: '#FFF',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="top"
                  align="right"
                  height={30}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px' }}
                />
                <Line
                  type="monotone"
                  name="Delivered"
                  dataKey="delivered"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#10B981' }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  name="In Transit"
                  dataKey="inTransit"
                  stroke="#3B82F6"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#3B82F6' }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  name="Pending"
                  dataKey="pending"
                  stroke="#F59E0B"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#F59E0B' }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Consignments Table (Matches screenshot!) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Recent Consignments
              </h3>
              <button
                onClick={() => setActiveNav('transactions-consignments')}
                className="text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline flex items-center gap-1"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800 font-semibold">
                    <th className="pb-2">AWB No.</th>
                    <th className="pb-2">Customer</th>
                    <th className="pb-2">Destination</th>
                    <th className="pb-2">Status</th>
                    <th className="pb-2 text-right">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {consignments.slice(0, 5).map((c) => (
                    <tr
                      key={c.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer group"
                      onClick={() => handleAwbClick(c.awbNumber)}
                    >
                      <td className="py-2.5 font-mono font-bold text-blue-600 dark:text-cyan-400 group-hover:underline">
                        {c.awbNumber}
                      </td>
                      <td className="py-2.5 font-medium text-slate-800 dark:text-slate-200 truncate max-w-[110px]">
                        {c.customerName}
                      </td>
                      <td className="py-2.5 text-slate-500 dark:text-slate-400">
                        {c.toCity}
                      </td>
                      <td className="py-2.5">
                        <StatusBadge status={c.status} size="sm" />
                      </td>
                      <td className="py-2.5 text-right text-slate-400 dark:text-slate-500 whitespace-nowrap">
                        {c.bookingDate.split(' ')[0]}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-slate-400 text-[11px]">
            <span>Showing latest 5 of {consignments.length} consignments</span>
            <button
              onClick={() => setActiveNav('transactions-consignments')}
              className="text-blue-600 dark:text-cyan-400 font-medium hover:underline"
            >
              Open Full Register →
            </button>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS & SYSTEM ALERTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Quick Actions (4 buttons matching screenshot) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
            Quick Actions
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            {/* Create Consignment */}
            <button
              onClick={() => setActiveNav('transactions-create-consignment')}
              className="flex items-center gap-3 p-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-sm transition-all group"
            >
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
                <PlusCircle className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold leading-tight">Create Consignment</p>
                <p className="text-[10px] text-blue-100 mt-0.5">Book new AWB</p>
              </div>
            </button>

            {/* Create Manifest */}
            <button
              onClick={() => setActiveNav('transactions-manifests')}
              className="flex items-center gap-3 p-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white shadow-sm transition-all group"
            >
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
                <FilePlus className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold leading-tight">Create Manifest</p>
                <p className="text-[10px] text-indigo-100 mt-0.5">Consolidate loads</p>
              </div>
            </button>

            {/* Track Shipment */}
            <button
              onClick={() => setActiveNav('transactions-tracking')}
              className="flex items-center gap-3 p-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white shadow-sm transition-all group"
            >
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
                <Search className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold leading-tight">Track Shipment</p>
                <p className="text-[10px] text-emerald-100 mt-0.5">Live status timeline</p>
              </div>
            </button>

            {/* Add Customer */}
            <button
              onClick={() => setActiveNav('master-customers')}
              className="flex items-center gap-3 p-3.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-sm transition-all group"
            >
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
                <UserPlus className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold leading-tight">Add Customer</p>
                <p className="text-[10px] text-cyan-100 mt-0.5">Outbound party</p>
              </div>
            </button>
          </div>
        </div>

        {/* System Alerts Panel (matching screenshot) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  System Alerts
                </h3>
              </div>
              <button
                onClick={() => setActiveNav('transactions-consignments')}
                className="text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
              >
                View All →
              </button>
            </div>

            <div className="space-y-3">
              {alerts.slice(0, 2).map((a) => (
                <div
                  key={a.id}
                  onClick={() => {
                    if (a.link) setActiveNav(a.link as any);
                  }}
                  className="flex items-start gap-3 p-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 cursor-pointer hover:bg-amber-100/50 transition-colors"
                >
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">
                      {a.title}
                    </p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">
                      {a.message}
                    </p>
                    <span className="text-[10px] text-amber-700 dark:text-amber-400 font-medium mt-1 inline-block">
                      {a.timestamp}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>SLA Monitoring: Active</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">● 100% Operational</span>
          </div>
        </div>
      </div>
    </div>
  );
};
