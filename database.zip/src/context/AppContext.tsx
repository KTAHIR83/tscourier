'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Consignment,
  Customer,
  CityMaster,
  AreaMaster,
  SlabMaster,
  RouteMaster,
  EmployeeMaster,
  ManifestCompanyMaster,
  StationMaster,
  ManifestCoLoaderMaster,
  TaxMaster,
  SupplierCourierMaster,
  Manifest,
  SystemAlert,
  UserProfile,
  ActiveNav,
  ShipmentStatus
} from '@/types';
import {
  initialCurrentUser,
  initialConsignments,
  initialCities,
  initialCustomers,
  initialAreas,
  initialSlabs,
  initialRoutes,
  initialEmployees,
  initialManifestCompanies,
  initialStations,
  initialLoaders,
  initialTaxEntries,
  initialSuppliers,
  initialManifests,
  initialAlerts
} from '@/data/mockData';

interface ToastState {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  isAuthenticated: boolean;
  currentUser: UserProfile;
  financialYear: string;
  setFinancialYear: (year: string) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  activeNav: ActiveNav;
  setActiveNav: (nav: ActiveNav) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean | ((prev: boolean) => boolean)) => void;
  mobileSidebarOpen: boolean;
  setMobileSidebarOpen: (v: boolean) => void;
  isGlobalSearchOpen: boolean;
  setIsGlobalSearchOpen: (v: boolean) => void;
  login: (username: string, password?: string, year?: string) => boolean;
  logout: () => void;
  
  // Data & CRUD
  consignments: Consignment[];
  addConsignment: (data: Omit<Consignment, 'id' | 'awbNumber' | 'bookingDate' | 'status'>) => Consignment;
  updateConsignmentStatus: (id: string, status: ShipmentStatus, location?: string) => void;
  deleteConsignment: (id: string) => void;

  cities: CityMaster[];
  addCity: (city: Omit<CityMaster, 'id' | 'createdDate'>) => void;
  updateCity: (id: string, city: Partial<CityMaster>) => void;
  deleteCity: (id: string) => void;

  customers: Customer[];
  addCustomer: (c: Omit<Customer, 'id' | 'createdDate'>) => void;
  updateCustomer: (id: string, c: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;

  areas: AreaMaster[];
  addArea: (a: Omit<AreaMaster, 'id'>) => void;
  deleteArea: (id: string) => void;

  slabs: SlabMaster[];
  addSlab: (s: Omit<SlabMaster, 'id'>) => void;
  updateSlab: (id: string, s: Partial<SlabMaster>) => void;
  deleteSlab: (id: string) => void;

  routes: RouteMaster[];
  addRoute: (r: Omit<RouteMaster, 'id'>) => void;
  deleteRoute: (id: string) => void;

  employees: EmployeeMaster[];
  addEmployee: (e: Omit<EmployeeMaster, 'id'>) => void;
  deleteEmployee: (id: string) => void;

  manifestCompanies: ManifestCompanyMaster[];
  addManifestCompany: (m: Omit<ManifestCompanyMaster, 'id'>) => void;
  deleteManifestCompany: (id: string) => void;

  stations: StationMaster[];
  addStation: (s: Omit<StationMaster, 'id'>) => void;
  deleteStation: (id: string) => void;

  loaders: ManifestCoLoaderMaster[];
  addLoader: (l: Omit<ManifestCoLoaderMaster, 'id'>) => void;
  deleteLoader: (id: string) => void;

  taxEntries: TaxMaster[];
  addTaxEntry: (t: Omit<TaxMaster, 'id'>) => void;
  deleteTaxEntry: (id: string) => void;

  suppliers: SupplierCourierMaster[];
  addSupplier: (s: Omit<SupplierCourierMaster, 'id'>) => void;
  deleteSupplier: (id: string) => void;

  manifests: Manifest[];
  addManifest: (m: Omit<Manifest, 'id'>) => void;

  alerts: SystemAlert[];
  markAlertAsRead: (id: string) => void;

  toasts: ToastState[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  quickTrackAwb: string | null;
  setQuickTrackAwb: (awb: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserProfile>(initialCurrentUser);
  const [financialYear, setFinancialYear] = useState<string>('2025-26');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [activeNav, setActiveNav] = useState<ActiveNav>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState<boolean>(false);
  const [quickTrackAwb, setQuickTrackAwb] = useState<string | null>(null);

  // Data states
  const [consignments, setConsignments] = useState<Consignment[]>(initialConsignments);
  const [cities, setCities] = useState<CityMaster[]>(initialCities);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [areas, setAreas] = useState<AreaMaster[]>(initialAreas);
  const [slabs, setSlabs] = useState<SlabMaster[]>(initialSlabs);
  const [routes, setRoutes] = useState<RouteMaster[]>(initialRoutes);
  const [employees, setEmployees] = useState<EmployeeMaster[]>(initialEmployees);
  const [manifestCompanies, setManifestCompanies] = useState<ManifestCompanyMaster[]>(initialManifestCompanies);
  const [stations, setStations] = useState<StationMaster[]>(initialStations);
  const [loaders, setLoaders] = useState<ManifestCoLoaderMaster[]>(initialLoaders);
  const [taxEntries, setTaxEntries] = useState<TaxMaster[]>(initialTaxEntries);
  const [suppliers, setSuppliers] = useState<SupplierCourierMaster[]>(initialSuppliers);
  const [manifests, setManifests] = useState<Manifest[]>(initialManifests);
  const [alerts, setAlerts] = useState<SystemAlert[]>(initialAlerts);
  const [toasts, setToasts] = useState<ToastState[]>([]);

  // Load data from localStorage on client mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedConsignments = localStorage.getItem('tsibis_consignments');
        if (savedConsignments) setConsignments(JSON.parse(savedConsignments));

        const savedSlabs = localStorage.getItem('tsibis_slabs');
        if (savedSlabs) setSlabs(JSON.parse(savedSlabs));

        const savedCustomers = localStorage.getItem('tsibis_customers');
        if (savedCustomers) setCustomers(JSON.parse(savedCustomers));

        const savedCities = localStorage.getItem('tsibis_cities');
        if (savedCities) setCities(JSON.parse(savedCities));

        const savedManifests = localStorage.getItem('tsibis_manifests');
        if (savedManifests) setManifests(JSON.parse(savedManifests));

        const savedAuth = localStorage.getItem('tsibis_auth');
        if (savedAuth) {
          const auth = JSON.parse(savedAuth);
          if (auth.isAuthenticated) {
            setIsAuthenticated(true);
            if (auth.currentUser) setCurrentUser(auth.currentUser);
            if (auth.financialYear) setFinancialYear(auth.financialYear);
          }
        }
      } catch (e) {
        console.warn('Could not read from localStorage', e);
      }
    }
  }, []);

  // Sync to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem('tsibis_consignments', JSON.stringify(consignments)); } catch (e) {}
    }
  }, [consignments]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem('tsibis_slabs', JSON.stringify(slabs)); } catch (e) {}
    }
  }, [slabs]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem('tsibis_customers', JSON.stringify(customers)); } catch (e) {}
    }
  }, [customers]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem('tsibis_cities', JSON.stringify(cities)); } catch (e) {}
    }
  }, [cities]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem('tsibis_manifests', JSON.stringify(manifests)); } catch (e) {}
    }
  }, [manifests]);

  // Dark mode effect
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const root = document.documentElement;
      if (theme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const login = (username: string, _password?: string, year?: string) => {
    const fy = year || financialYear;
    if (year) setFinancialYear(fy);
    setIsAuthenticated(true);
    const user = {
      ...initialCurrentUser,
      username: username || 'admin',
      name: username === 'admin' ? 'Admin' : username,
    };
    setCurrentUser(user);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('tsibis_auth', JSON.stringify({ isAuthenticated: true, currentUser: user, financialYear: fy }));
      } catch (e) {}
    }
    setActiveNav('dashboard');
    showToast(`Welcome back, ${user.name}! Successfully authenticated.`);
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('tsibis_auth');
      } catch (e) {}
    }
    showToast('You have been logged out securely.', 'info');
  };

  const addConsignment = (data: Omit<Consignment, 'id' | 'awbNumber' | 'bookingDate' | 'status'>) => {
    const nextNum = 4588 + (consignments.length - initialConsignments.length);
    const awbNumber = `TSB0000${nextNum}`;
    const newCsg: Consignment = {
      ...data,
      id: `csg-${Date.now()}`,
      awbNumber,
      bookingDate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'Booked',
      currentLocation: `${data.fromCity} Origin Hub`,
    };
    setConsignments((prev) => [newCsg, ...prev]);
    showToast(`Consignment ${awbNumber} booked successfully!`, 'success');
    return newCsg;
  };

  const updateConsignmentStatus = (id: string, status: ShipmentStatus, location?: string) => {
    setConsignments((prev) =>
      prev.map((c) =>
        c.id === id || c.awbNumber === id
          ? {
              ...c,
              status,
              currentLocation: location || c.currentLocation,
              deliveredDate: status === 'Delivered' ? new Date().toISOString().replace('T', ' ').substring(0, 16) : c.deliveredDate,
            }
          : c
      )
    );
    showToast(`Consignment status updated to ${status}.`, 'info');
  };

  const deleteConsignment = (id: string) => {
    setConsignments((prev) => prev.filter((c) => c.id !== id && c.awbNumber !== id));
    showToast('Consignment deleted.', 'info');
  };

  // City CRUD
  const addCity = (city: Omit<CityMaster, 'id' | 'createdDate'>) => {
    const newCity: CityMaster = {
      ...city,
      id: `city-${Date.now()}`,
      createdDate: new Date().toISOString().split('T')[0],
    };
    setCities((prev) => [newCity, ...prev]);
    showToast(`City "${city.cityName}" added to master successfully.`, 'success');
  };

  const updateCity = (id: string, updated: Partial<CityMaster>) => {
    setCities((prev) => prev.map((c) => (c.id === id ? { ...c, ...updated } : c)));
    showToast('City details updated.', 'success');
  };

  const deleteCity = (id: string) => {
    setCities((prev) => prev.filter((c) => c.id !== id));
    showToast('City removed from master.', 'info');
  };

  // Customer CRUD
  const addCustomer = (c: Omit<Customer, 'id' | 'createdDate'>) => {
    const newCustomer: Customer = {
      ...c,
      id: `cust-${Date.now()}`,
      createdDate: new Date().toISOString().split('T')[0],
    };
    setCustomers((prev) => [newCustomer, ...prev]);
    showToast(`Customer "${c.name}" registered successfully.`, 'success');
  };

  const updateCustomer = (id: string, updated: Partial<Customer>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...updated } : c)));
    showToast('Customer information updated.', 'success');
  };

  const deleteCustomer = (id: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    showToast('Customer record archived.', 'info');
  };

  // Area CRUD
  const addArea = (a: Omit<AreaMaster, 'id'>) => {
    setAreas((prev) => [{ ...a, id: `area-${Date.now()}` }, ...prev]);
    showToast(`Area "${a.areaName}" added.`, 'success');
  };
  const deleteArea = (id: string) => {
    setAreas((prev) => prev.filter((a) => a.id !== id));
    showToast('Area removed.', 'info');
  };

  // Slab CRUD
  const addSlab = (s: Omit<SlabMaster, 'id'>) => {
    setSlabs((prev) => [{ ...s, id: `slab-${Date.now()}` }, ...prev]);
    showToast(`Rate slab "${s.slabName}" created.`, 'success');
  };
  const updateSlab = (id: string, updated: Partial<SlabMaster>) => {
    setSlabs((prev) => prev.map((s) => (s.id === id ? { ...s, ...updated } : s)));
    showToast('Rate slab details updated successfully.', 'success');
  };
  const deleteSlab = (id: string) => {
    setSlabs((prev) => prev.filter((s) => s.id !== id));
    showToast('Rate slab deleted.', 'info');
  };

  // Route CRUD
  const addRoute = (r: Omit<RouteMaster, 'id'>) => {
    setRoutes((prev) => [{ ...r, id: `route-${Date.now()}` }, ...prev]);
    showToast(`Route "${r.routeCode}" created.`, 'success');
  };
  const deleteRoute = (id: string) => {
    setRoutes((prev) => prev.filter((r) => r.id !== id));
    showToast('Route removed.', 'info');
  };

  // Employee CRUD
  const addEmployee = (e: Omit<EmployeeMaster, 'id'>) => {
    setEmployees((prev) => [{ ...e, id: `emp-${Date.now()}` }, ...prev]);
    showToast(`Employee "${e.name}" added.`, 'success');
  };
  const deleteEmployee = (id: string) => {
    setEmployees((prev) => prev.filter((e) => e.id !== id));
    showToast('Employee removed.', 'info');
  };

  // Manifest Company CRUD
  const addManifestCompany = (m: Omit<ManifestCompanyMaster, 'id'>) => {
    setManifestCompanies((prev) => [{ ...m, id: `mc-${Date.now()}` }, ...prev]);
    showToast(`Manifest company "${m.companyName}" added.`, 'success');
  };
  const deleteManifestCompany = (id: string) => {
    setManifestCompanies((prev) => prev.filter((m) => m.id !== id));
    showToast('Manifest company removed.', 'info');
  };

  // Station CRUD
  const addStation = (s: Omit<StationMaster, 'id'>) => {
    setStations((prev) => [{ ...s, id: `st-${Date.now()}` }, ...prev]);
    showToast(`Station "${s.stationName}" added.`, 'success');
  };
  const deleteStation = (id: string) => {
    setStations((prev) => prev.filter((s) => s.id !== id));
    showToast('Station removed.', 'info');
  };

  // Loader CRUD
  const addLoader = (l: Omit<ManifestCoLoaderMaster, 'id'>) => {
    setLoaders((prev) => [{ ...l, id: `ldr-${Date.now()}` }, ...prev]);
    showToast(`Co-loader "${l.loaderName}" added.`, 'success');
  };
  const deleteLoader = (id: string) => {
    setLoaders((prev) => prev.filter((l) => l.id !== id));
    showToast('Co-loader removed.', 'info');
  };

  // Tax CRUD
  const addTaxEntry = (t: Omit<TaxMaster, 'id'>) => {
    setTaxEntries((prev) => [{ ...t, id: `tax-${Date.now()}` }, ...prev]);
    showToast(`Tax Master entry "${t.taxName}" added.`, 'success');
  };
  const deleteTaxEntry = (id: string) => {
    setTaxEntries((prev) => prev.filter((t) => t.id !== id));
    showToast('Tax entry removed.', 'info');
  };

  // Supplier CRUD
  const addSupplier = (s: Omit<SupplierCourierMaster, 'id'>) => {
    setSuppliers((prev) => [{ ...s, id: `sup-${Date.now()}` }, ...prev]);
    showToast(`Courier supplier "${s.courierName}" added.`, 'success');
  };
  const deleteSupplier = (id: string) => {
    setSuppliers((prev) => prev.filter((s) => s.id !== id));
    showToast('Supplier removed.', 'info');
  };

  // Manifest CRUD
  const addManifest = (m: Omit<Manifest, 'id'>) => {
    setManifests((prev) => [{ ...m, id: `mnf-${Date.now()}` }, ...prev]);
    showToast(`Manifest "${m.manifestNo}" dispatched successfully.`, 'success');
  };

  // Alert
  const markAlertAsRead = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        financialYear,
        setFinancialYear,
        theme,
        toggleTheme,
        activeNav,
        setActiveNav,
        sidebarCollapsed,
        setSidebarCollapsed,
        mobileSidebarOpen,
        setMobileSidebarOpen,
        isGlobalSearchOpen,
        setIsGlobalSearchOpen,
        login,
        logout,
        consignments,
        addConsignment,
        updateConsignmentStatus,
        deleteConsignment,
        cities,
        addCity,
        updateCity,
        deleteCity,
        customers,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        areas,
        addArea,
        deleteArea,
        slabs,
        addSlab,
        updateSlab,
        deleteSlab,
        routes,
        addRoute,
        deleteRoute,
        employees,
        addEmployee,
        deleteEmployee,
        manifestCompanies,
        addManifestCompany,
        deleteManifestCompany,
        stations,
        addStation,
        deleteStation,
        loaders,
        addLoader,
        deleteLoader,
        taxEntries,
        addTaxEntry,
        deleteTaxEntry,
        suppliers,
        addSupplier,
        deleteSupplier,
        manifests,
        addManifest,
        alerts,
        markAlertAsRead,
        toasts,
        showToast,
        removeToast,
        quickTrackAwb,
        setQuickTrackAwb,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
