-- ==========================================================
-- TSIBIS SOLUTION (INDEX EXPRESS SERVICE)
-- INITIAL DATA SEED SCRIPT (SQL DML)
-- ==========================================================

-- Insert Default Admin User
INSERT INTO users (id, username, name, email, role, branch)
VALUES ('usr_001', 'admin', 'Admin', 'operations@tsibis.in', 'Administrator', 'New Delhi Corporate Hub');

-- Insert Cities Master
INSERT INTO cities (id, city_name, state, country, pin_code, zone, status, created_date) VALUES
('city_01', 'Delhi', 'Delhi (NCT)', 'India', '110001', 'North', 'Active', '2024-01-10'),
('city_02', 'Mumbai', 'Maharashtra', 'India', '400001', 'West', 'Active', '2024-01-10'),
('city_03', 'Lucknow', 'Uttar Pradesh', 'India', '226001', 'North', 'Active', '2024-01-12'),
('city_04', 'Kanpur', 'Uttar Pradesh', 'India', '208001', 'North', 'Active', '2024-01-12'),
('city_05', 'Jaipur', 'Rajasthan', 'India', '302001', 'North', 'Active', '2024-01-15'),
('city_06', 'Kolkata', 'West Bengal', 'India', '700001', 'East', 'Active', '2024-01-18'),
('city_07', 'Bengaluru', 'Karnataka', 'India', '560001', 'South', 'Active', '2024-01-20'),
('city_08', 'Ahmedabad', 'Gujarat', 'India', '380001', 'West', 'Active', '2024-01-22'),
('city_09', 'Hyderabad', 'Telangana', 'India', '500001', 'South', 'Active', '2024-02-01'),
('city_10', 'Pune', 'Maharashtra', 'India', '411001', 'West', 'Active', '2024-02-05'),
('city_11', 'Varanasi', 'Uttar Pradesh', 'India', '221001', 'North', 'Active', '2024-02-10'),
('city_12', 'Chandigarh', 'Punjab / Haryana', 'India', '160017', 'North', 'Active', '2024-02-14');

-- Insert Customers Master
INSERT INTO customers (id, code, name, contact_person, phone, email, city, gst_no, outstanding_balance, credit_limit, status, created_date) VALUES
('cust_01', 'CUST-1001', 'Sharma Traders', 'Ramesh Sharma', '+91 98101 23456', 'sharma.traders@gmail.com', 'Delhi', '07AAAAA1234A1Z5', 42500.00, 150000.00, 'Active', '2024-02-15'),
('cust_02', 'CUST-1002', 'Global Logistics Pvt Ltd', 'Amitabh Sengupta', '+91 98220 99881', 'dispatch@globallogistics.co.in', 'Mumbai', '27AABCG5544B1Z9', 118400.00, 300000.00, 'Active', '2024-02-18'),
('cust_03', 'CUST-1003', 'RK Enterprises', 'Rajnish Kumar', '+91 94140 12345', 'rk.enterprises.jpr@yahoo.com', 'Jaipur', '08AAACR8877C1Z2', 15600.00, 80000.00, 'Active', '2024-03-01'),
('cust_04', 'CUST-1004', 'Apex Services & Hardware', 'Gautam Banerjee', '+91 98300 44556', 'accounts@apexkolkata.in', 'Kolkata', '19AAACA3322D1Z8', 63200.00, 200000.00, 'Active', '2024-03-12'),
('cust_05', 'CUST-1005', 'S.K. Traders Kanpur', 'Sunil Kapoor', '+91 94500 77889', 'sktraders.kanpur@rediffmail.com', 'Kanpur', '09AAACS9988E1Z4', 8750.00, 100000.00, 'Active', '2024-03-20'),
('cust_06', 'CUST-1006', 'Hind Logistics Co', 'Mahesh Deshpande', '+91 98900 12389', 'info@hindlogistics.com', 'Pune', '27AAACH1100F1Z1', 32000.00, 120000.00, 'Active', '2024-04-05'),
('cust_07', 'CUST-1007', 'Patel Brothers & Sons', 'Bhavin Patel', '+91 98250 33445', 'orders@patelbrothers.biz', 'Ahmedabad', '24AAACP4411G1Z7', 5400.00, 90000.00, 'Active', '2024-04-18');

-- Insert Sample Consignments
INSERT INTO consignments (id, awb_number, customer_id, customer_name, sender_phone, recipient_name, recipient_phone, from_city, to_city, service_type, payment_type, weight, pieces, declared_value, delivery_address, area, pin_code, status, booking_date, delivered_date, current_location, notes) VALUES
('csg_01', 'TSB00004587', 'cust_01', 'Sharma Traders', '+91 98101 23456', 'Vikas Sharma', '+91 98765 43210', 'Kanpur', 'Delhi', 'Express Air', 'Paid', 4.5, 2, 18500.00, 'Plot 42, Okhla Industrial Area Phase III', 'Okhla', '110020', 'Delivered', '2025-08-24 09:30', '2025-08-25 14:15', 'Delhi Delivery Hub', 'Fragile electrical components enclosed.'),
('csg_02', 'TSB00004586', 'cust_02', 'Global Logistics', '+91 98220 99881', 'Kunal Deshmukh', '+91 97654 32109', 'Delhi', 'Mumbai', 'Surface Cargo', 'TBB (To-Be-Billed)', 28.0, 6, 64000.00, 'Godown 14, Bhiwandi Logistics Park', 'Bhiwandi', '421302', 'In Transit', '2025-08-24 11:20', NULL, 'Nashik Transit Gateway', 'Direct warehouse delivery required.'),
('csg_03', 'TSB00004585', 'cust_03', 'RK Enterprises', '+91 94140 12345', 'Sunil Rathore', '+91 94141 55667', 'Ahmedabad', 'Jaipur', 'Standard Express', 'To-Pay', 7.2, 3, 24500.00, 'Shop 108, Johari Bazaar', 'Johari Bazaar', '302003', 'Pending', '2025-08-23 15:45', NULL, 'Jaipur Sorting Hub', 'Recipient requested afternoon delivery attempt.'),
('csg_04', 'TSB00004584', 'cust_04', 'Apex Services', '+91 98300 44556', 'Subhasish Sen', '+91 98310 88990', 'Lucknow', 'Kolkata', 'Express Air', 'Paid', 3.0, 1, 12000.00, 'Tower B, Sector V, Salt Lake City', 'Salt Lake Sector V', '700091', 'Delivered', '2025-08-23 10:15', '2025-08-24 16:30', 'Salt Lake Delivery Hub', 'Signature collected from recipient reception.'),
('csg_05', 'TSB00004583', 'cust_05', 'S.K. Traders', '+91 94500 77889', 'Mohd. Faisal', '+91 94150 11223', 'Kanpur', 'Lucknow', 'Same Day Hub', 'TBB (To-Be-Billed)', 12.5, 4, 35000.00, '54/2 Hazratganj Commercial Complex', 'Hazratganj', '226001', 'In Transit', '2025-08-22 17:00', NULL, 'Kanpur-Lucknow Expressway Van', 'Critical pharmaceutical shipment.');

-- Insert Routes Master
INSERT INTO routes (id, route_code, origin_city, destination_city, via_cities, distance_km, standard_transit_days, status) VALUES
('rt_01', 'RT-DEL-BOM', 'Delhi', 'Mumbai', 'Jaipur, Ahmedabad', 1420, 2, 'Active'),
('rt_02', 'RT-KNP-DEL', 'Kanpur', 'Delhi', 'Agra, Aligarh', 480, 1, 'Active'),
('rt_03', 'RT-DEL-CCU', 'Delhi', 'Kolkata', 'Kanpur, Varanasi, Patna', 1530, 3, 'Active'),
('rt_04', 'RT-LKO-DEL', 'Lucknow', 'Delhi', 'Bareilly, Moradabad', 550, 1, 'Active');

-- Insert Manifests
INSERT INTO manifests (id, manifest_no, date, carrier_name, co_loader, route_code, origin_city, dest_city, consignment_count, total_weight, total_pieces, vehicle_no, driver_name, driver_phone, status) VALUES
('mnf_01', 'MNF-2025-08-0091', '2025-08-25', 'Index Express Line', 'IndiGo Cargo Logistics', 'RT-DEL-BOM', 'Delhi', 'Mumbai', 142, 840.5, 320, 'DL-01-AB-8842', 'Suraj Bhan', '+91 98112 34990', 'In Transit'),
('mnf_02', 'MNF-2025-08-0090', '2025-08-24', 'Delhivery Surface Freight', 'Northern Road Freighters', 'RT-KNP-DEL', 'Kanpur', 'Delhi', 98, 620.0, 195, 'UP-78-BT-4109', 'Rampal Sharma', '+91 94500 33112', 'Received at Hub');
