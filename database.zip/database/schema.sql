-- ==========================================================
-- TSIBIS SOLUTION (INDEX EXPRESS SERVICE)
-- ENTERPRISE LOGISTICS DATABASE SCHEMA (SQL DDL)
-- Compatible with PostgreSQL, SQLite, MySQL, and SQL Server
-- ==========================================================

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    role VARCHAR(50) DEFAULT 'Administrator',
    branch VARCHAR(100) DEFAULT 'New Delhi Corporate Hub',
    avatar_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Customers / Outbound Party Master Table
CREATE TABLE IF NOT EXISTS customers (
    id VARCHAR(36) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(25),
    email VARCHAR(100),
    city VARCHAR(100) NOT NULL,
    gst_no VARCHAR(20),
    outstanding_balance DECIMAL(12,2) DEFAULT 0.00,
    credit_limit DECIMAL(12,2) DEFAULT 100000.00,
    status VARCHAR(20) DEFAULT 'Active',
    created_date VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Cities Master Table
CREATE TABLE IF NOT EXISTS cities (
    id VARCHAR(36) PRIMARY KEY,
    city_name VARCHAR(100) UNIQUE NOT NULL,
    state VARCHAR(100) NOT NULL,
    country VARCHAR(50) DEFAULT 'India',
    pin_code VARCHAR(10) NOT NULL,
    zone VARCHAR(20) DEFAULT 'North',
    status VARCHAR(20) DEFAULT 'Active',
    created_date VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Areas Master Table
CREATE TABLE IF NOT EXISTS areas (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(150) NOT NULL,
    city_name VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    pin_code VARCHAR(10) NOT NULL,
    delivery_hub VARCHAR(100) DEFAULT 'Central Hub',
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Tariff Slabs Master Table
CREATE TABLE IF NOT EXISTS slabs (
    id VARCHAR(36) PRIMARY KEY,
    slab_code VARCHAR(50) UNIQUE NOT NULL,
    slab_name VARCHAR(150) NOT NULL,
    service_type VARCHAR(50) NOT NULL,
    min_weight_kg DECIMAL(8,2) NOT NULL,
    max_weight_kg DECIMAL(8,2) NOT NULL,
    base_rate DECIMAL(10,2) NOT NULL,
    extra_rate_per_kg DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Routes Master Table
CREATE TABLE IF NOT EXISTS routes (
    id VARCHAR(36) PRIMARY KEY,
    route_code VARCHAR(50) UNIQUE NOT NULL,
    origin_city VARCHAR(100) NOT NULL,
    destination_city VARCHAR(100) NOT NULL,
    via_cities TEXT,
    distance_km INT NOT NULL,
    standard_transit_days INT NOT NULL,
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Employees Master Table
CREATE TABLE IF NOT EXISTS employees (
    id VARCHAR(36) PRIMARY KEY,
    emp_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    branch VARCHAR(100) NOT NULL,
    phone VARCHAR(25),
    email VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Manifest Companies Master Table
CREATE TABLE IF NOT EXISTS manifest_companies (
    id VARCHAR(36) PRIMARY KEY,
    company_code VARCHAR(50) UNIQUE NOT NULL,
    company_name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(25),
    email VARCHAR(100),
    city VARCHAR(100) NOT NULL,
    gst_no VARCHAR(20),
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. Stations Master Table
CREATE TABLE IF NOT EXISTS stations (
    id VARCHAR(36) PRIMARY KEY,
    station_code VARCHAR(50) UNIQUE NOT NULL,
    station_name VARCHAR(150) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    hub_type VARCHAR(50) DEFAULT 'Delivery Hub',
    contact_person VARCHAR(100),
    phone VARCHAR(25),
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. Manifest Co-Loaders Master Table
CREATE TABLE IF NOT EXISTS manifest_co_loaders (
    id VARCHAR(36) PRIMARY KEY,
    loader_code VARCHAR(50) UNIQUE NOT NULL,
    loader_name VARCHAR(150) NOT NULL,
    supported_services TEXT,
    contact_person VARCHAR(100),
    phone VARCHAR(25),
    city VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. Tax Master Table (GST)
CREATE TABLE IF NOT EXISTS tax_entries (
    id VARCHAR(36) PRIMARY KEY,
    tax_code VARCHAR(50) UNIQUE NOT NULL,
    tax_name VARCHAR(150) NOT NULL,
    hsn_code VARCHAR(20) NOT NULL,
    cgst_rate DECIMAL(5,2) NOT NULL,
    sgst_rate DECIMAL(5,2) NOT NULL,
    igst_rate DECIMAL(5,2) NOT NULL,
    effective_from VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 12. Supplier / Courier Master Table
CREATE TABLE IF NOT EXISTS suppliers_courier (
    id VARCHAR(36) PRIMARY KEY,
    supplier_code VARCHAR(50) UNIQUE NOT NULL,
    courier_name VARCHAR(150) NOT NULL,
    service_modes TEXT,
    tracking_portal_url TEXT,
    contact_person VARCHAR(100),
    phone VARCHAR(25),
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 13. Consignments Table (Core Transaction Ledger)
CREATE TABLE IF NOT EXISTS consignments (
    id VARCHAR(36) PRIMARY KEY,
    awb_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id VARCHAR(36) REFERENCES customers(id),
    customer_name VARCHAR(150) NOT NULL,
    sender_phone VARCHAR(25),
    recipient_name VARCHAR(150) NOT NULL,
    recipient_phone VARCHAR(25) NOT NULL,
    from_city VARCHAR(100) NOT NULL,
    to_city VARCHAR(100) NOT NULL,
    service_type VARCHAR(50) DEFAULT 'Express Air',
    payment_type VARCHAR(50) DEFAULT 'Paid',
    weight DECIMAL(8,2) DEFAULT 1.00,
    pieces INT DEFAULT 1,
    declared_value DECIMAL(12,2) DEFAULT 1000.00,
    delivery_address TEXT NOT NULL,
    area VARCHAR(100),
    pin_code VARCHAR(10) NOT NULL,
    status VARCHAR(50) DEFAULT 'Booked',
    booking_date VARCHAR(30) NOT NULL,
    delivered_date VARCHAR(30),
    current_location VARCHAR(150),
    notes TEXT,
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 14. Manifests Table
CREATE TABLE IF NOT EXISTS manifests (
    id VARCHAR(36) PRIMARY KEY,
    manifest_no VARCHAR(50) UNIQUE NOT NULL,
    date VARCHAR(20) NOT NULL,
    carrier_name VARCHAR(150) NOT NULL,
    co_loader VARCHAR(150),
    route_code VARCHAR(50) NOT NULL,
    origin_city VARCHAR(100) NOT NULL,
    dest_city VARCHAR(100) NOT NULL,
    consignment_count INT DEFAULT 0,
    total_weight DECIMAL(10,2) DEFAULT 0.00,
    total_pieces INT DEFAULT 0,
    vehicle_no VARCHAR(50),
    driver_name VARCHAR(100),
    driver_phone VARCHAR(25),
    status VARCHAR(50) DEFAULT 'Dispatched',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 15. Tracking Events Table
CREATE TABLE IF NOT EXISTS tracking_events (
    id VARCHAR(36) PRIMARY KEY,
    consignment_id VARCHAR(36) REFERENCES consignments(id),
    awb_number VARCHAR(50) NOT NULL,
    timestamp VARCHAR(30) NOT NULL,
    location VARCHAR(150) NOT NULL,
    status VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    facility VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 16. System Alerts Table
CREATE TABLE IF NOT EXISTS system_alerts (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(20) DEFAULT 'info',
    timestamp VARCHAR(30) NOT NULL,
    read BOOLEAN DEFAULT FALSE,
    link VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_consignments_awb ON consignments(awb_number);
CREATE INDEX IF NOT EXISTS idx_consignments_status ON consignments(status);
CREATE INDEX IF NOT EXISTS idx_customers_code ON customers(code);
CREATE INDEX IF NOT EXISTS idx_cities_name ON cities(city_name);
CREATE INDEX IF NOT EXISTS idx_manifests_no ON manifests(manifest_no);
CREATE INDEX IF NOT EXISTS idx_tracking_awb ON tracking_events(awb_number);
